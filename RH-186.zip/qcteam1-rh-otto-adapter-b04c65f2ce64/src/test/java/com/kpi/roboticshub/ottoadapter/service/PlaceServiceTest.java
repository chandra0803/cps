/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.ottoadapter.ContainerType;
import com.kpi.roboticshub.api.ottoadapter.place.PlaceResult;
import com.kpi.roboticshub.api.ottoadapter.place.PlaceTrafficResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.matchers.Times;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

/**
 * Represents a test that validates the internal api requests placed by {@link PlaceService}.
 *
 * @author Jacob.Richards
 */
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PlaceServiceTest
{
  private ClientAndServer mockServer;

  @Autowired
  private OttoAdapterProperties properties;
  @Autowired
  private PlaceService          placeService;
  @Autowired
  private ObjectMapper          objectMapper;

  @BeforeAll
  public void start() throws JsonProcessingException
  {
    // start mock servers on all unique ports
    mockServer = ClientAndServer.startClientAndServer(properties.getBaseUrl().getPort());
    // Errors
    mockServer.when(request().withQueryStringParameter("id", "places-error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    mockServer.when(request().withQueryStringParameter("id", "places-traffic-error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    // Places Traffic
    mockServer.when(request().withPath(GET_PLACES_TRAFFIC_PATH).withQueryStringParameter("id"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPlaceTrafficIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(GET_PLACES_TRAFFIC_PATH), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPlaceTrafficResponse())).withStatusCode(200));
    // Places
    mockServer.when(request().withPath(GET_PLACES_PATH).withQueryStringParameter("id"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPlaceByIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(GET_PLACES_PATH), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPlacesResponse())).withStatusCode(200));
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void getPlacesTest()
  {
    List<PlaceResult> testPlaceResults = getPlacesResponse();
    List<PlaceResult> placeResults = placeService.getPlaces();
    assertEquals(placeResults.size(), testPlaceResults.size(), "placeResults size does not match provided data.");

    for (int i = 0; i < placeResults.size(); i++)
    {
      assertEquals(placeResults.get(i).getId(), testPlaceResults.get(i).getId(), "Ids do not match.");
      assertEquals(placeResults.get(i).getSourceId(), testPlaceResults.get(i).getSourceId(), "SourceIds do not match.");
      assertEquals(placeResults.get(i).getCreated(), testPlaceResults.get(i).getCreated(),
                   "Created dates do not match.");
    }
  }

  @Test
  void getPlaceByIdTest()
  {
    List<PlaceResult> testPlaceIdResults = getPlaceByIdResponse();
    List<PlaceResult> placeResultsById = placeService.getPlace("1ea1f84a68e4fa65135ik13h4");
    assertEquals(placeResultsById.size(), testPlaceIdResults.size(),
                 "placeResultsById size does not match provided data.");
    assertEquals(placeResultsById.get(0).getId(), testPlaceIdResults.get(0).getId(), "Ids do not match.");
  }

  @Test
  void getPlaceByIdSpecialCharacterTest()
  {
    List<PlaceResult> testPlaceIdResults = getPlaceByIdResponse();
    List<PlaceResult> placeResultsById = placeService.getPlace(".1:e!0a1f298<>'0984$a68e;4fa65@135ik13h4");
    assertEquals(placeResultsById.size(), testPlaceIdResults.size(),
                 "placeResultsById size does not match provided data.");
    assertEquals(placeResultsById.get(0).getId(), testPlaceIdResults.get(0).getId(), "Ids do not match.");
  }

  @Test
  void getPlaceError()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> placeService.getPlace("places-error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError());
  }

  @Test
  void getPlaceTraffic()
  {
    List<PlaceTrafficResult> testPlaceTrafficResults = getPlaceTrafficResponse();
    List<PlaceTrafficResult> placeTrafficResults = placeService.getPlaceTraffic();
    assertEquals(placeTrafficResults.size(), testPlaceTrafficResults.size());
    for (int i = 0; i < placeTrafficResults.size(); i++)
    {
      assertEquals(placeTrafficResults.get(i).getId(), testPlaceTrafficResults.get(i).getId());
    }
  }

  @Test
  void getPlaceTrafficById()
  {
    List<PlaceTrafficResult> testPlaceTrafficIdResults = getPlaceTrafficIdResponse();
    List<PlaceTrafficResult> placeTrafficIdResults = placeService.getPlaceTraffic("6947798-3999421-244");
    assertEquals(placeTrafficIdResults.size(), testPlaceTrafficIdResults.size());
    assertEquals(placeTrafficIdResults.get(0).getId(), testPlaceTrafficIdResults.get(0).getId());
  }

  @Test
  void getPlaceTrafficError()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> placeService.getPlaceTraffic("places-traffic-error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError());
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private List<PlaceResult> getPlaceByIdResponse()
  {
    List<PlaceResult> placeResultList = new ArrayList<>();
    PlaceResult placeResult = PlaceResult.builder()
        .created("2020-08-04T15:36:53.364622Z")
        .description("Client defined description for this record.")
        .isEnabled(true)
        .exitRecipe("bb97cc60-2a63-42ee-a420-475664502de2")
        .featureQueue("984ef48l494yhn148s")
        .id("1ea1f84a68e4fa65135ik13h4")
        .name("Place by Id Test")
        .ownershipQueue("981894gea41v-a864b-468av")
        .placeGroups(
            "[4595e2e6-fe00-4751-a694-09200dbe9a80,489gea4-58-48ea64-5fea4-981b68a4e, 286fafg-12e68a-486-21849-a4li84yh4]")
        .placeType("STANDARD")
        .primaryMarkerId("4fea897ga-0568ea-351-8410-04fae89t4faa")
        .primaryMarkerIntent("OTTO154CHARGER")
        .sourceId("168fea-198eaf-4751-a694-3v184ge6a1d4851")
        .zone("2387ga4d-4702-4f9b-a166-419v98ae41")
        .build();

    placeResultList.add(placeResult);

    return placeResultList;
  }

  private List<PlaceResult> getPlacesResponse()
  {
    ContainerType containerType = ContainerType.builder()
        .description("This type represents a cart that can be picked up with an OTTO 100 platform.")
        .id("703e61e3-f86a-4ef5-8b58-47f581358059")
        .name("OTTO100_CART")
        .robotPropertyName("builtin_lift")
        .robotPropertyType("lift")
        .build();

    Map<String, Object> recipes = new HashMap<>();
    recipes.put("CHARGE", null);
    recipes.put("CONTAINER_EMPTY", null);
    recipes.put("CONTAINER_FILL", null);
    recipes.put("LOAD", "83d687a0-fa09-4a64-a996-942831813d36");
    recipes.put("MOVE", "48d8d9a8a-b744-4c2b-91a4-a2ab3c61b3d3");
    recipes.put("MUTATE", "49dab1c5-89ab-471c-b33a-5f4e18f7abce");
    recipes.put("TRANSPORT", null);
    recipes.put("UNLOAD", null);
    recipes.put("WORK_IN_PLACE", "ec3c059c-fd43-47a9-b3fb-5ef620d446d9");

    PlaceResult placeResult = PlaceResult.builder()
        .containerTypesSupported(List.of(containerType))
        .created("2018-11-05T15:36:53.364622Z")
        .description("Client defined description for this record.")
        .isEnabled(true)
        .exitRecipe("bb97cc60-2a63-42ee-a420-475664502de2")
        .featureQueue("86b0a6e0-14d5-4f40-ab4c-5ac985491c50")
        .id("f81d4fae-7dec-11d0-a765-00a0c91e6bf6")
        .name("Client defined name")
        .ownershipQueue("4595e2e6-fe00-4751-a694-09200dbe9a80")
        .placeGroups(
            "[4595e2e6-fe00-4751-a694-09200dbe9a80, f372a966-4702-4f9b-a166-d52aaaaad035, 73fce6ff-371f-4464-9302-6807453b6be3]")
        .placeType("STANDARD")
        .primaryMarkerId("4595e2e6-fe00-4751-a694-09200dbe9a80")
        .primaryMarkerIntent("OTTO100_CHARGER")
        .recipes(List.of(recipes))
        .sourceId("4595e2e6-fe00-4751-a694-09200dbe9a80")
        .zone("f372a966-4702-4f9b-a166-d52aaaaad035")
        .build();

    ContainerType containerType2 = ContainerType.builder()
        .description("This type represents a cart that can be picked up with an OTTO 154 platform.")
        .id("1584ea48681")
        .name("OTTO154_CART")
        .robotPropertyName("builtin_lift")
        .robotPropertyType("lift")
        .build();

    PlaceResult placeResult2 = PlaceResult.builder()
        .containerTypesSupported(List.of(containerType2))
        .created("2020-08-04T15:36:53.364622Z")
        .description("Client defined description for this record.")
        .isEnabled(true)
        .exitRecipe("bb97cc60-2a63-42ee-a420-475664502de2")
        .featureQueue("984ef48l494yhn148s")
        .id("1ea1f84a68e4fa65135ik13h4")
        .name("Client defined name")
        .ownershipQueue("981894gea41v-a864b-468av")
        .placeGroups(
            "[4595e2e6-fe00-4751-a694-09200dbe9a80,489gea4-58-48ea64-5fea4-981b68a4e, 286fafg-12e68a-486-21849-a4li84yh4]")
        .placeType("STANDARD")
        .primaryMarkerId("4fea897ga-0568ea-351-8410-04fae89t4faa")
        .primaryMarkerIntent("OTTO154CHARGER")
        .sourceId("168fea-198eaf-4751-a694-3v184ge6a1d4851")
        .zone("2387ga4d-4702-4f9b-a166-419v98ae41")
        .build();

    List<PlaceResult> placeResultList = new ArrayList<>();
    placeResultList.add(placeResult);
    placeResultList.add(placeResult2);

    return placeResultList;
  }

  private List<PlaceTrafficResult> getPlaceTrafficIdResponse()
  {
    List<String> queue = new ArrayList<>();
    queue.add("aet-948721-4aef-14");
    queue.add("alj9-2135-12jfakkl");
    queue.add("lji-99981j-ljfieka");

    PlaceTrafficResult placeTrafficResult = PlaceTrafficResult.builder()
        .id("6947798-3999421-244")
        .owner("testOwner")
        .queue(queue)
        .build();

    List<PlaceTrafficResult> placeTrafficResults = new ArrayList<>();
    placeTrafficResults.add(placeTrafficResult);

    return placeTrafficResults;
  }

  private List<PlaceTrafficResult> getPlaceTrafficResponse()
  {
    List<String> queue = new ArrayList<>();
    queue.add("aet-213fgad31-4aef-14");
    queue.add("alj9-9rjfa9-12jfakkl");
    queue.add("lji-ljieafjie-ljfieka");

    PlaceTrafficResult placeTrafficResult = PlaceTrafficResult.builder()
        .id("22134-3999421-244")
        .owner("testOwner")
        .queue(queue)
        .build();

    List<String> queue2 = new ArrayList<>();
    queue2.add("jifea-213fgad31-4aef-14");
    queue2.add("mmckw-9rjfa9-12jfakkl");
    queue2.add("pooiwa-ljieafjie-ljfieka");

    PlaceTrafficResult placeTrafficResult2 = PlaceTrafficResult.builder()
        .id("98747921-3999421-244")
        .owner("OwnerTest2")
        .queue(queue2)
        .build();

    List<PlaceTrafficResult> placeTrafficResults = new ArrayList<>();
    placeTrafficResults.add(placeTrafficResult);
    placeTrafficResults.add(placeTrafficResult2);

    return placeTrafficResults;
  }
}
