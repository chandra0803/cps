package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ApiError;
import com.kpi.roboticshub.api.ApiErrorConstants;
import com.kpi.roboticshub.api.ottoadapter.ClientException;
import com.kpi.roboticshub.api.ottoadapter.mission.CreateMission;
import com.kpi.roboticshub.ottoadapter.OttoActivityService;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoPathConstants;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockserver.integration.ClientAndServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class OttoRetryMissionServiceTest
{
  @Autowired
  OttoActivityService ottoActivityService;
  private ClientAndServer       mockServer;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;

  @BeforeAll
  public void start() throws IOException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withPath(
            OttoPathConstants.MISSION_OPERATIONS_PATH)
        )
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getCreatedMission())).withStatusCode(200));

    mockServer.when(request().withPath(
            OttoPathConstants.MISSION_OPERATIONS_PATH)
        )
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getCreatedMission())).withStatusCode(400));

  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  public void retryMissionTest() throws IOException
  {
    Activity testActivity = getActivity();
    ottoActivityService.processMission(getActivity());
    Activity activityRetry = getRetryActivity();
    activityRetry.getActivityDetail().setActivityId(testActivity.getActivityDetail().getActivityId());
    ottoActivityService.processMission(getRetryActivity());

    assertEquals("A5A3EB48-1E10-4829-80CB-3B181D5339AD", testActivity.getActivityDetail().getActivityId());
  }

  @Test
  public void retryMissionFailTest() throws IOException
  {
    ottoActivityService.processMission(getActivity());
    List<ApiError> errors = new ArrayList<>();
    errors.add(ApiError.builder().errorId(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_ID)
                   .description(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_DESCRIPTION).build());
    ClientException clientException = new ClientException(getActivity(), errors, HttpStatus.BAD_REQUEST);
    Activity activityRetry = getRetryActivity();
    activityRetry.getActivityDetail().setActivityId("doesnotexists");
    ottoActivityService.processMission(getRetryActivity());

    assertEquals(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_ID, clientException.getErrors().get(0).getErrorId());
    assertEquals(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_DESCRIPTION,
                 clientException.getErrors().get(0).getDescription());
    assertEquals(HttpStatus.BAD_REQUEST, clientException.getStatus());

  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private CreateMission getCreatedMission() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-created-mission.json"), CreateMission.class);
  }

  private Activity getActivity() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-activity.json"),
                                  Activity.class);
  }

  private Activity getRetryActivity() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-retry-activity.json"), Activity.class);
  }

  private InputStream getInputStream(String jsonPath)
  {
    return TypeReference.class.getResourceAsStream(jsonPath);
  }

}
