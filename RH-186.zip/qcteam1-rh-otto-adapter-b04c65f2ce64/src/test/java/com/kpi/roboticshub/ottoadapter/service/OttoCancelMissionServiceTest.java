package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ottoadapter.mission.CancelMission;
import com.kpi.roboticshub.ottoadapter.OttoActivityService;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoPathConstants;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.mockserver.integration.ClientAndServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class OttoCancelMissionServiceTest
{
  @Autowired
  OttoActivityService ottoActivityService;

  private ClientAndServer       mockServer;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;

  @BeforeAll
  public void start() throws IOException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withPath(
            OttoPathConstants.MISSION_OPERATIONS_PATH)
        )
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getCancelMission())).withStatusCode(200));

  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  public void cancelMissionTest() throws IOException
  {
    Activity testActivity = getActivity();
    ottoActivityService.processMission(getActivity());
    Activity activityCancel = getCancelActivity();
    activityCancel.getActivityDetail().setActivityId(testActivity.getActivityDetail().getActivityId());
    Boolean cancelData = ottoActivityService.cancelMission(activityCancel.getActivityDetail().getActivityId());

    assertEquals(Boolean.TRUE, cancelData);
  }

  @Test
  public void cancelMissionFailWhenNullTest() throws IOException
  {
    Activity activityCancel = getCancelActivity();
    activityCancel.getActivityDetail().setActivityId(null);
    Boolean cancelData = ottoActivityService.cancelMission(activityCancel.getActivityDetail().getActivityId());

    assertEquals(Boolean.FALSE, cancelData);
  }

  @Test
  public void cancelMissionFailActivityIdNotExistTest() throws IOException
  {
    Activity activityCancel = getCancelActivity();
    activityCancel.getActivityDetail().setActivityId("doesnotexists");
    Boolean cancelData = ottoActivityService.cancelMission(activityCancel.getActivityDetail().getActivityId());

    assertEquals(Boolean.FALSE, cancelData);
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private CancelMission getCancelMission() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-cancel-mission.json"), CancelMission.class);
  }

  private Activity getActivity() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-activity.json"),
                                  Activity.class);
  }

  private Activity getCancelActivity() throws IOException
  {
    return objectMapper.readValue(getInputStream("/get-cancel-activity.json"), Activity.class);
  }

  private InputStream getInputStream(String jsonPath)
  {
    return TypeReference.class.getResourceAsStream(jsonPath);
  }

}
