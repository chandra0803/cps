package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.ottoadapter.payload.PayloadResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.matchers.Times;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.PAYLOAD_OPERATIONS_PATH;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PayloadResultServiceTest
{
  private ClientAndServer       mockServer;
  @Autowired
  private PayloadResultService  payloadResultService;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;

  @BeforeAll
  public void start() throws IOException, JsonProcessingException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withQueryStringParameter("id", "error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    mockServer.when(request().withPath(
                PAYLOAD_OPERATIONS_PATH)
                        .withQueryStringParameter("id", "")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPayloadResultResponseEmpty())).withStatusCode(200));
    mockServer.when(request().withPath(
                PAYLOAD_OPERATIONS_PATH)
                        .withQueryStringParameter("id", "1")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPayloadResultByIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(PAYLOAD_OPERATIONS_PATH).withQueryStringParameter("fields", "*"),
                    Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getPayloadResultResponse())).withStatusCode(200));

  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void getPlayLoadErrorTest()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> payloadResultService.getPayloadResults(
                                                                       "error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError());
  }

  @Test
  void getPayloadResultTest() throws IOException
  {
    List<PayloadResult> testPayloadResults = getPayloadResultResponse();
    List<PayloadResult> payloadResults = payloadResultService.getPayloadResults();
    for (int index = 0; index < payloadResults.size(); index++)
    {
      assertEquals(payloadResults.get(index).getId(), testPayloadResults.get(index).getId());
      assertEquals(payloadResults.get(index).getName(), testPayloadResults.get(index).getName());
      assertEquals(payloadResults.get(index).getDescription(), testPayloadResults.get(index).getDescription());
      assertEquals(payloadResults.get(index).getRobot(), testPayloadResults.get(index).getRobot());
      assertEquals(payloadResults.get(index).getCreated(), testPayloadResults.get(index).getCreated());
    }
  }

  @Test
  void getPayloadResultEmptyTest() throws IOException
  {
    List<PayloadResult> testPayloadResults = getPayloadResultResponseEmpty();
    List<PayloadResult> payloadResults = payloadResultService.getPayloadResults("");
    assertEquals(payloadResults.size(), testPayloadResults.size());
  }

  @Test
  void getPayloadResultByIdTest() throws IOException
  {
    List<PayloadResult> testPayloadResults = getPayloadResultByIdResponse();
    List<PayloadResult> payloadResults = payloadResultService.getPayloadResults("1");
    for (int index = 0; index < payloadResults.size(); index++)
    {
      assertEquals(payloadResults.get(index).getId(), testPayloadResults.get(index).getId());
      assertEquals(payloadResults.get(index).getName(), testPayloadResults.get(index).getName());
      assertEquals(payloadResults.get(index).getDescription(), testPayloadResults.get(index).getDescription());
      assertEquals(payloadResults.get(index).getRobot(), testPayloadResults.get(index).getRobot());
      assertEquals(payloadResults.get(index).getCreated(), testPayloadResults.get(index).getCreated());
    }
  }

  private List<PayloadResult> getPayloadResultByIdResponse() throws IOException
  {
    return createPayloadResults("1");
  }

  private List<PayloadResult> getPayloadResultResponse() throws IOException
  {
    return createPayloadResults(null);
  }

  private List<PayloadResult> getPayloadResultResponseEmpty() throws IOException
  {
    List<PayloadResult> payloadResults = new ArrayList<>();
    return payloadResults;
  }

  public List<PayloadResult> createPayloadResults(String id) throws IOException
  {
    InputStream inputStream;
    if (id == null)
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-payload-result-list.json");
    }
    else
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-payload-result.json");
    }
    return objectMapper.readValue(inputStream, getReference());
  }

  protected TypeReference<List<PayloadResult>> getReference()
  {
    return new TypeReference<>()
    {
    };
  }
}