/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.Response;
import com.kpi.roboticshub.api.ottoadapter.mission.OttoResponse;

import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Contains various testing methods.
 *
 * @author sja
 */
public final class TestUtilities
{
  /**
   * Creates a new instance of the {@link TestUtilities} class.
   */
  private TestUtilities()
  {
    // do nothing
  }

  public static void assertNoErrors(Response<?> response)
  {
    assertTrue(response != null
               && (response.getErrors() == null
                   || response.getErrors().size() == 0));
  }

  public static void assertResponseContainsError(Response<?> response, String errorId)
  {
    assertTrue(response != null
               && response.getErrors() != null
               && response.getErrors().stream().anyMatch(x -> Objects.equals(x.getErrorId(), errorId)),
               "Response errors do not contain [%s]".formatted(errorId));
  }

  public static OttoResponse createMissionOperationsResponse_OK()
  {
    return OttoResponse.builder().id(123456).version("2.0").method("createMission").build();
  }

  public static boolean assertErrorExists(ValidationException exception, String valueName, String errorId)
  {
    return exception.getErrors().stream()
        .anyMatch(x -> Objects.equals(x.getErrorId(), errorId)
                       && x.getDescription() != null
                       && x.getDescription().contains(valueName));
  }

  public static boolean assertErrorExists(ValidationException exception, String valueName, String errorId,
                                          String lineId)
  {
    return exception.getErrors().stream()
        .anyMatch(x -> Objects.equals(x.getErrorId(), errorId)
                       && x.getDescription() != null
                       && x.getDescription().contains(valueName)
                       && x.getInnerId().equals(lineId));
  }
}
