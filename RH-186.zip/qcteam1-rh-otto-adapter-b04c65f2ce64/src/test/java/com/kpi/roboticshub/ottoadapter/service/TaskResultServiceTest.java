package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.ottoadapter.task.TaskResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.matchers.Times;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_TASKS_PATH;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

/**
 * Contains {@link TaskResultService} tests.
 */
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class TaskResultServiceTest
{
  private ClientAndServer       mockServer;
  @Autowired
  private TaskResultService     taskResultService;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;

  @BeforeAll
  public void start() throws IOException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withQueryStringParameter("id", "error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    mockServer.when(request().withPath(
                GET_TASKS_PATH)
                        .withQueryStringParameter("id", "")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getTaskResultResponseEmpty())).withStatusCode(200));
    mockServer.when(request().withPath(
                GET_TASKS_PATH)
                        .withQueryStringParameter("id", "1")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getTaskByIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(GET_TASKS_PATH)
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getTaskResultResponse())).withStatusCode(200));
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void getTaskResultTest() throws IOException
  {
    List<TaskResult> testTaskResults = getTaskResultResponse();
    List<TaskResult> taskResults = taskResultService.getTaskResults();
    for (int index = 0; index < taskResults.size(); index++)
    {
      assertEquals(taskResults.get(index).getId(), testTaskResults.get(index).getId());
      assertEquals(taskResults.get(index).getMission(), testTaskResults.get(index).getMission());
      assertEquals(taskResults.get(index).getContainerType(), testTaskResults.get(index).getContainerType());
      assertEquals(taskResults.get(index).getPlaceGroup(), testTaskResults.get(index).getPlaceGroup());
      assertEquals(taskResults.get(index).getPlace(), testTaskResults.get(index).getPlace());
    }
  }

  @Test
  void getTaskResultErrorTest()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> taskResultService.getTaskResults("error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError());
  }

  @Test
  void getTaskResultByIdTest() throws IOException
  {
    List<TaskResult> testTaskResults = getTaskByIdResponse();
    List<TaskResult> taskResults = taskResultService.getTaskResults("1");
    for (int index = 0; index < taskResults.size(); index++)
    {
      assertEquals(taskResults.get(index).getId(), testTaskResults.get(index).getId());
      assertEquals(taskResults.get(index).getMission(), testTaskResults.get(index).getMission());
      assertEquals(taskResults.get(index).getContainerType(), testTaskResults.get(index).getContainerType());
      assertEquals(taskResults.get(index).getPlaceGroup(), testTaskResults.get(index).getPlaceGroup());
      assertEquals(taskResults.get(index).getPlace(), testTaskResults.get(index).getPlace());
    }
  }

  @Test
  void getTaskResultEmptyTest() throws IOException
  {
    List<TaskResult> testTaskResults = getTaskResultResponseEmpty();
    List<TaskResult> taskResults = taskResultService.getTaskResults("");
    assertEquals(taskResults.size(), testTaskResults.size());
  }

  private List<TaskResult> getTaskResultResponseEmpty()
  {
    List<TaskResult> taskResults = new ArrayList<>();
    return taskResults;
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private List<TaskResult> getTaskByIdResponse() throws IOException
  {
    return createTasksResults("1");
  }

  private List<TaskResult> getTaskResultResponse() throws IOException
  {
    return createTasksResults(null);
  }

  public List<TaskResult> createTasksResults(String id) throws IOException
  {
    InputStream inputStream;
    if (id == null)
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-tasks-result-list.json");
    }
    else
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-task-result.json");
    }
    return objectMapper.readValue(inputStream, getReference());
  }

  protected TypeReference<List<TaskResult>> getReference()
  {
    return new TypeReference<>()
    {
    };
  }
}
