package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.adapter.mongo.SubscriptionRepository;
import com.kpi.roboticshub.adapter.mongo.entity.Subscription;
import com.kpi.roboticshub.adapter.mongo.entity.SubscriptionType;
import com.kpi.roboticshub.api.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.net.URI;

import static com.kpi.roboticshub.api.ApiErrorConstants.*;
import static com.kpi.roboticshub.ottoadapter.TestUtilities.assertNoErrors;
import static com.kpi.roboticshub.ottoadapter.TestUtilities.assertResponseContainsError;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Represents a {@link OttoReceiveService} test.
 */
@SpringBootTest
public class OttoReceiveServiceTest
{
  @Autowired
  private OttoReceiveService     ottoReceiveService;
  @Autowired
  private SubscriptionRepository ottoSubscriptionRepository;

  @BeforeEach
  public void before()
  {
    ottoSubscriptionRepository.deleteAll();
  }

  @Test
  void addValidSubscription()
  {
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.addSubscription(getValidSubscription());
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNoErrors(response.getBody());
  }

  @Test
  void addInvalidSubscription()
  {
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.addSubscription(getInvalidSubscription());
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertResponseContainsError(response.getBody(), INVALID_CALLBACK_URL_ID);
  }

  @Test
  void addExistingValidSubscription()
  {
    Subscription subscription = getValidSubscription();
    ottoSubscriptionRepository.save(subscription);
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.addSubscription(subscription);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertResponseContainsError(response.getBody(), CALLBACK_URL_ALREADY_EXISTS_ID);
  }

  @Test
  void addExistingInvalidSubscription()
  {
    Subscription subscription = getInvalidSubscription();
    ottoSubscriptionRepository.save(subscription);
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.addSubscription(subscription);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertResponseContainsError(response.getBody(), CALLBACK_URL_ALREADY_EXISTS_ID);
  }

  @Test
  void updateExistingSubscription()
  {
    Subscription subscription = getValidSubscription();
    ottoSubscriptionRepository.save(subscription);
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.updateSubscription(subscription);
    assertEquals(HttpStatus.OK, response.getStatusCode());
    assertNoErrors(response.getBody());
  }

  @Test
  void updateNonExistingSubscription()
  {
    Subscription subscription = getValidSubscription();
    ResponseEntity<Response<Subscription>> response = ottoReceiveService.updateSubscription(subscription);
    assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    assertResponseContainsError(response.getBody(), CALLBACK_URL_DOES_NOT_EXIST_ID);
  }

  @Test
  void cancelExistingSubscription()
  {
    Subscription subscription = getValidSubscription();
    ottoSubscriptionRepository.save(subscription);
    Boolean response = ottoReceiveService.cancelSubscription(subscription.getUrl().toString());
    assertEquals(true, response);
  }

  @Test
  void cancelNonExistingSubscription()
  {
    Subscription subscription = getValidSubscription();
    Boolean response = ottoReceiveService.cancelSubscription(subscription.getUrl().toString());
    assertEquals(false, response);
  }

  private Subscription getInvalidSubscription()
  {
    return new Subscription(URI.create("*invalid-url$"), SubscriptionType.ALL);
  }

  private Subscription getValidSubscription()
  {
    return new Subscription(URI.create("https://valid-url.com/v1/messages"), SubscriptionType.ALL);
  }
}
