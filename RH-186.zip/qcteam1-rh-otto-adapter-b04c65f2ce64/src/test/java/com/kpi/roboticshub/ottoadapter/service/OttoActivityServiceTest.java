/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.adapter.mongo.ActivityService;
import com.kpi.roboticshub.adapter.mongo.MessageService;
import com.kpi.roboticshub.adapter.mongo.entity.ActivityWrapper;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ActivityType;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import com.kpi.roboticshub.api.ottoadapter.mission.CreateMission;
import com.kpi.roboticshub.api.ottoadapter.mission.OttoMessage;
import com.kpi.roboticshub.api.ottoadapter.mission.UpdateMission;
import com.kpi.roboticshub.api.ottoadapter.task.OttoTaskType;
import com.kpi.roboticshub.ottoadapter.OttoActivityService;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoPathConstants;
import com.kpi.roboticshub.ottoadapter.TestUtilities;
import com.kpi.roboticshub.ottoadapter.converter.OttoMissionConverter;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import java.io.IOException;
import java.io.InputStream;
import java.util.Optional;

import static com.kpi.roboticshub.api.ApiErrorConstants.PARAMS_MISSING_REQUIRED_VALUE_ID;
import static com.kpi.roboticshub.ottoadapter.TestUtilities.assertErrorExists;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

/**
 * Represents a {@link com.kpi.roboticshub.ottoadapter.OttoActivityService} test
 *
 * @author KarnakarChitikaneni
 */
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class OttoActivityServiceTest
{
  private ClientAndServer mockServer;

  @Autowired
  private OttoActivityService   ottoActivityService;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private ActivityService       activityService;
  @Autowired
  private OttoMissionConverter  ottoMissionConverter;
  @Autowired
  private MessageService        messageService;

  @BeforeEach
  public void before()
  {
    activityService.getRepository().deleteAll();
    messageService.getRepository().deleteAll();
  }

  @BeforeAll
  public void start() throws IOException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withPath(
            OttoPathConstants.MISSION_OPERATIONS_PATH))
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(TestUtilities.createMissionOperationsResponse_OK())).withStatusCode(200));
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void updateMissionTest() throws IOException
  {
    ottoActivityService.processMission(getActivityRequestForPick());

    Activity activityMove = getActivityRequestForMove();
    activityMove.getActivityDetail().setActivityId(getActivityRequestForPick().getActivityDetail().getActivityId());
    ottoActivityService.processMission(activityMove);
    Optional<ActivityWrapper> activity = activityService.getRepository()
        .findById(activityMove.getActivityDetail().getActivityId());
    assertNotNull(activity.get());
    assertEquals(activity.get().getDataObject().getActivityType(), activityMove.getActivityType());
    assertEquals(activity.get().getDataObject().getDeviceType(), activityMove.getDeviceType());
    assertEquals(activity.get().getDataObject().getSystemId(), activityMove.getSystemId());
    assertEquals(activity.get().getDataObject().getActivityDetail().getActivityId(),
                 activityMove.getActivityDetail().getActivityId());
    assertEquals(HttpStatus.OK, activity.get().getStatus());
  }

  @Test
  void testConversionForUpdate() throws IOException
  {
    ottoActivityService.processMission(getActivityRequestForPick());
    Activity activityMove = getActivityRequestForMove();
    activityMove.getActivityDetail().setActivityId(getActivityRequestForPick().getActivityDetail().getActivityId());

    OttoMessage<?> ottoMessage = ottoMissionConverter.convert(activityMove);
    assertEquals(ottoMessage.getMethod(), MessageMethod.UPDATE_MISSION.getMethod());
    assertEquals(ottoMessage.getVersion(), ottoAdapterProperties.getVersion());
    assert (ottoMessage.getParams() instanceof UpdateMission);
    UpdateMission updateMission = (UpdateMission) ottoMessage.getParams();
    assertEquals(updateMission.getId(), activityMove.getActivityDetail().getActivityId());
    assertEquals(updateMission.getTasks().get(0).getTaskType(), OttoTaskType.MOVE.name());
    assertEquals(updateMission.getTasks().get(0).getPlace(),
                 getLocationTranslation(activityMove.getActivityDetail().getDestination().getLocationId()));

  }

  @Test
  void testConversionForCreate() throws IOException
  {
    Activity activityMove = getActivityRequestForMove();
    OttoMessage<?> ottoMessage = ottoMissionConverter.convert(getActivityRequestForMove());
    assertEquals(ottoMessage.getMethod(), MessageMethod.CREATE_MISSION.getMethod());
    assertEquals(ottoMessage.getVersion(), ottoAdapterProperties.getVersion());
    assert (ottoMessage.getParams() instanceof CreateMission);
    CreateMission createMission = (CreateMission) ottoMessage.getParams();
    assertEquals(createMission.getMission().getClientReferenceId(), activityMove.getActivityDetail().getActivityId());
    assertEquals(createMission.getTasks().get(0).getTaskType(), OttoTaskType.MOVE.name());
    assertEquals(createMission.getTasks().get(0).getPlace(),
                 getLocationTranslation(activityMove.getActivityDetail().getDestination().getLocationId()));

  }

  @Test
  void testMoveActivityForLocationIdMissing() throws IOException
  {
    Activity activityMove = getActivityRequestForMove();
    activityMove.getActivityDetail().getDestination().setLocationId(null);
    ValidationException validationException;
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityMove));
    assertTrue(assertErrorExists(validationException, "locationId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityMove.getActivityDetail().setDestination(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityMove));
    assertTrue(assertErrorExists(validationException, "destination", PARAMS_MISSING_REQUIRED_VALUE_ID));
  }

  @Test
  void testPickActivityForRequiredFields() throws IOException
  {
    Activity activityPick = getActivityRequestForPick();
    activityPick.getActivityDetail().getContainers().get(0).setContainerId(null);
    ValidationException validationException;
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityPick));
    assertTrue(assertErrorExists(validationException, "containerId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityPick.getActivityDetail().getContainers().get(0).getLocation().setLocationId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityPick));
    assertTrue(assertErrorExists(validationException, "locationId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityPick.getActivityDetail().setContainers(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityPick));
    assertTrue(assertErrorExists(validationException, "containers", PARAMS_MISSING_REQUIRED_VALUE_ID));

  }

  @Test
  void testDropActivityForRequiredFields() throws IOException
  {
    Activity activityDrop = getActivityRequestForDrop();
    ValidationException validationException;

    activityDrop.getActivityDetail().getContainers().get(0).setContainerId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityDrop));
    assertTrue(assertErrorExists(validationException, "containerId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityDrop.getActivityDetail().getDestination().setLocationId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityDrop));

    assertTrue(assertErrorExists(validationException, "locationId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityDrop.getActivityDetail().setDestination(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityDrop));

    assertTrue(assertErrorExists(validationException, "destination", PARAMS_MISSING_REQUIRED_VALUE_ID));

    activityDrop.getActivityDetail().setContainers(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      activityDrop));

    assertTrue(assertErrorExists(validationException, "containers", PARAMS_MISSING_REQUIRED_VALUE_ID));

  }

  @Test
  void testFourQuarterCycleMissionRequest() throws IOException
  {
    testStoreActivityForRequiredFields(ActivityType.STORE.getType());
    testStoreActivityForRequiredFields(ActivityType.SHUFFLE.getType());
    testStoreActivityForRequiredFields(ActivityType.RETRIEVE.getType());
  }

  void testStoreActivityForRequiredFields(String activityType) throws IOException
  {
    Activity fourQuarterCycleActivity = getActivityRequestForFourQuarterCycle();
    fourQuarterCycleActivity.setActivityType(activityType);
    ValidationException validationException;

    fourQuarterCycleActivity.getActivityDetail().getContainers().get(0).setContainerId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      fourQuarterCycleActivity));
    assertTrue(assertErrorExists(validationException, "containerId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    fourQuarterCycleActivity.getActivityDetail().getDestination().setLocationId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      fourQuarterCycleActivity));

    assertTrue(assertErrorExists(validationException, "locationId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    fourQuarterCycleActivity.getActivityDetail().setDestination(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      fourQuarterCycleActivity));

    assertTrue(assertErrorExists(validationException, "destination", PARAMS_MISSING_REQUIRED_VALUE_ID));

    fourQuarterCycleActivity.getActivityDetail().getContainers().get(0).getLocation().setLocationId(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      fourQuarterCycleActivity));
    assertTrue(assertErrorExists(validationException, "locationId", PARAMS_MISSING_REQUIRED_VALUE_ID));

    fourQuarterCycleActivity.getActivityDetail().setContainers(null);
    validationException = Assertions.assertThrows(ValidationException.class,
                                                  () -> ottoActivityService.processMission(
                                                      fourQuarterCycleActivity));

    assertTrue(assertErrorExists(validationException, "containers", PARAMS_MISSING_REQUIRED_VALUE_ID));

  }

  private String getLocationTranslation(String locationId)
  {
    String locationTranslation = ottoAdapterProperties.getLocationMap().get(locationId);
    return locationTranslation != null ? locationTranslation : locationId;
  }

  public Activity getActivityRequestForPick() throws IOException
  {
    return createActivityRequest("/pick-activity.json");
  }

  public Activity getActivityRequestForMove() throws IOException
  {
    return createActivityRequest("/move-activity.json");
  }

  public Activity getActivityRequestForDrop() throws IOException
  {
    return createActivityRequest("/drop-activity.json");
  }

  public Activity getActivityRequestForFourQuarterCycle() throws IOException
  {
    return createActivityRequest("/store-activity.json");
  }

  public Activity createActivityRequest(String path) throws IOException
  {
    InputStream inputStream = TypeReference.class.getResourceAsStream(path);
    return objectMapper.readValue(inputStream, getReference());
  }

  protected TypeReference<Activity> getReference()
  {
    return new TypeReference<>()
    {
    };
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

}
