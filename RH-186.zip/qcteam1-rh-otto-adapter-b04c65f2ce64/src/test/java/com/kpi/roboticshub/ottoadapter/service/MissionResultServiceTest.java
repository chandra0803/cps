package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.ottoadapter.mission.MissionResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoPathConstants;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.matchers.Times;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_MISSION_PATH;
import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.PAYLOAD_OPERATIONS_PATH;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MissionResultServiceTest
{
  private ClientAndServer       mockServer;
  @Autowired
  private MissionResultService  missionResultService;
  @Autowired
  private ObjectMapper          objectMapper;
  @Autowired
  private OttoAdapterProperties ottoAdapterProperties;

  @BeforeAll
  public void start() throws IOException
  {
    // start mock server
    mockServer = ClientAndServer.startClientAndServer(ottoAdapterProperties.getBaseUrl().getPort());
    mockServer.when(request().withQueryStringParameter("client_reference_id", "error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    mockServer.when(request().withPath(
                GET_MISSION_PATH)
                        .withQueryStringParameter("client_reference_id", "")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getMissionResultResponseEmpty())).withStatusCode(200));
    mockServer.when(request().withPath(
                OttoPathConstants.GET_MISSION_PATH)
                        .withQueryStringParameter("client_reference_id", "1")
                        .withQueryStringParameter("fields", "*"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getMissionResultByIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(OttoPathConstants.GET_MISSION_PATH).withQueryStringParameter("fields", "*"),
                    Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getMissionResultResponse())).withStatusCode(200));
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void getMissionResultTest() throws IOException
  {
    List<MissionResult> testMissionResults = getMissionResultResponse();
    List<MissionResult> missionResults = missionResultService.getMissionResults();
    for (int index = 0; index < missionResults.size(); index++)
    {
      assertEquals(missionResults.get(index).getClientReferenceId(),
                   testMissionResults.get(index).getClientReferenceId());
      assertEquals(missionResults.get(index).getMissionStatus(),
                   testMissionResults.get(index).getMissionStatus());
      assertEquals(missionResults.get(index).getResultText(),
                   testMissionResults.get(index).getResultText());
      assertEquals(missionResults.get(index).getCurrentTask(),
                   testMissionResults.get(index).getCurrentTask());
    }
  }

  @Test
  void getMissionResultErrorTest()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> missionResultService.getMissionResults(
                                                                       "error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError());
  }

  @Test
  void getMissionResultEmptyTest() throws IOException
  {
    List<MissionResult> testMissionResults = getMissionResultResponseEmpty();
    List<MissionResult> missionResults = missionResultService.getMissionResults("");
    assertEquals(missionResults.size(), testMissionResults.size());
  }

  @Test
  void getMissionResultByIdTest() throws IOException
  {
    List<MissionResult> testMissionResults = getMissionResultResponse();
    List<MissionResult> missionResults = missionResultService.getMissionResults("1");
    for (int index = 0; index < missionResults.size(); index++)
    {
      assertEquals(missionResults.get(index).getClientReferenceId(),
                   testMissionResults.get(index).getClientReferenceId());
      assertEquals(missionResults.get(index).getMissionStatus(),
                   testMissionResults.get(index).getMissionStatus());
      assertEquals(missionResults.get(index).getResultText(),
                   testMissionResults.get(index).getResultText());
      assertEquals(missionResults.get(index).getCurrentTask(),
                   testMissionResults.get(index).getCurrentTask());
    }
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private List<MissionResult> getMissionResultByIdResponse() throws IOException
  {
    return createMissionResults("1");
  }

  private List<MissionResult> getMissionResultResponse() throws IOException
  {
    return createMissionResults(null);
  }

  private List<MissionResult> getMissionResultResponseEmpty() throws IOException
  {
    List<MissionResult> missionResults = new ArrayList<>();
    return missionResults;
  }

  public List<MissionResult> createMissionResults(String clientReferenceId) throws IOException
  {
    InputStream inputStream;
    if (clientReferenceId == null)
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-mission-result-list.json");
    }
    else
    {
      inputStream = TypeReference.class.getResourceAsStream("/get-mission-result.json");
    }
    return objectMapper.readValue(inputStream, getReference());
  }

  protected TypeReference<List<MissionResult>> getReference()
  {
    return new TypeReference<>()
    {
    };
  }
}
