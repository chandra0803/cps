/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kpi.roboticshub.api.ottoadapter.map.MapResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import org.junit.jupiter.api.*;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.matchers.Times;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_MAPS_PATH;
import static org.apache.commons.lang3.RandomStringUtils.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

/**
 * Represents a test that validates the internal api requests placed by {@link MapService}.
 *
 * @author Jacob.Richards
 */
@SpringBootTest
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class MapServiceTest
{
  private ClientAndServer mockServer;

  @Autowired
  private OttoAdapterProperties properties;
  @Autowired
  private MapService            mapService;
  @Autowired
  private ObjectMapper          objectMapper;

  @BeforeAll
  public void start() throws JsonProcessingException
  {
    // start mock servers on all unique ports
    mockServer = ClientAndServer.startClientAndServer(properties.getBaseUrl().getPort());
    // Errors
    mockServer.when(request().withQueryStringParameter("id", "maps-error-500"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withStatusCode(500));
    // Maps
    mockServer.when(request().withQueryStringParameter("id"), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getMapIdResponse())).withStatusCode(200));
    mockServer.when(request().withPath(GET_MAPS_PATH), Times.unlimited())
        .respond(response().withHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                     .withBody(getAsString(getMapsResponse())).withStatusCode(200));
  }

  @AfterAll
  public void stop()
  {
    mockServer.stop();
  }

  @Test
  void getMapsTest()
  {
    List<MapResult> testMapResults = getMapsResponse();
    List<MapResult> mapResults = mapService.getMapResults();
    assertEquals(testMapResults.size(), mapResults.size());

    for (int i = 0; i < mapResults.size(); i++)
    {
      assertEquals(testMapResults.get(i).getId(), mapResults.get(i).getId(), "Ids do not match.");
    }
  }

  @Test
  void getMapsByIdTest()
  {
    List<MapResult> testMapByIdResults = getMapIdResponse();
    List<MapResult> mapByIdResults = mapService.getMapResults("JIAGHE-29384-AKOWENP");
    assertEquals(testMapByIdResults.size(), mapByIdResults.size(), "mapByIdResults size does not match provided data.");
    assertEquals(testMapByIdResults.get(0).getId(), mapByIdResults.get(0).getId(), "Ids do not match.");
  }

  @Test
  void getMapsByIdSpecialCharacterTest()
  {
    List<MapResult> testMapByIdResults = getMapIdResponse();
    List<MapResult> mapByIdResults = mapService.getMapResults(".1:H!JFIEV9U7<>'0984$AJ93F;JG83A@JFIE98NVC4");
    assertEquals(mapByIdResults.size(), testMapByIdResults.size(),
                 "mapByIdResults size does not match provided data.");
    assertEquals(mapByIdResults.get(0).getId(), testMapByIdResults.get(0).getId(), "Ids do not match.");
  }

  @Test
  void getMapsError()
  {
    WebClientResponseException exception = Assertions.assertThrows(WebClientResponseException.class,
                                                                   () -> mapService.getMapResults("maps-error-500"));
    assertTrue(exception.getStatusCode().is5xxServerError(), "500 Error was not thrown.");
  }

  private String getAsString(Object object) throws JsonProcessingException
  {
    return objectMapper.writeValueAsString(object);
  }

  private List<MapResult> getMapsResponse()
  {
    List<MapResult> mapResults = new ArrayList<>();

    MapResult mapResult = MapResult.builder()
        .id("JAIGE93-1238-KDJFNVA")
        .description("Map Description")
        .created(OffsetDateTime.now().toString())
        .name("MAP-91FJ2")
        .isCached(false)
        .isDisabled(false)
        .project("PROJECT-12094JJF-293")
        .sourceMap("FJFJIA09NBM-VIURQ23")
        .tag("IENV8-938NF")
        .build();

    MapResult mapResult2 = MapResult.builder()
        .id("URPIMCAI23-1238-KDJFNVA")
        .description("Map Description")
        .created(OffsetDateTime.now().toString())
        .name("MAP-QOINA2")
        .isCached(false)
        .isDisabled(false)
        .project("PROJECT-BNALOWIURFJ-2442")
        .sourceMap("GHTYRLDN98FNV-N092V")
        .tag("VNOIJ-WOE983")
        .build();

    mapResults.add(mapResult);
    mapResults.add(mapResult2);

    return mapResults;
  }

  private List<MapResult> getMapIdResponse()
  {
    List<MapResult> mapResults = new ArrayList<>();

    MapResult mapResult = MapResult.builder()
        .id("JIAGHE-29384-AKOWENP")
        .description(randomAlphabetic(0, 50))
        .created(OffsetDateTime.now().toString())
        .name(randomAlphabetic(0, 50))
        .isCached(false)
        .isDisabled(false)
        .project(randomAlphabetic(0, 50))
        .sourceMap(randomAlphabetic(0, 50))
        .tag(randomAlphabetic(0, 50))
        .build();

    mapResults.add(mapResult);
    return mapResults;
  }
}
