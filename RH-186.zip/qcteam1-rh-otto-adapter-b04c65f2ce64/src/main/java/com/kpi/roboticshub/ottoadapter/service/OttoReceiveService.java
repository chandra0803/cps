/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.adapter.mongo.SubscriptionRepository;
import com.kpi.roboticshub.adapter.mongo.entity.Subscription;
import com.kpi.roboticshub.adapter.mongo.entity.SubscriptionType;
import com.kpi.roboticshub.adapter.service.RoboticsHubReceiveService;
import com.kpi.roboticshub.api.*;
import com.kpi.roboticshub.ottoadapter.OttoActivityService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static com.kpi.roboticshub.api.ApiErrorConstants.*;

/**
 * Represents an OTTO {@link RoboticsHubReceiveService}.
 *
 * @author sja
 */
@Service
public class OttoReceiveService implements RoboticsHubReceiveService
{
  private final OttoActivityService    ottoActivityService;
  private final SubscriptionRepository subscriptionRepository;

  /**
   * Creates a new instance of the {@link OttoReceiveService} class.
   */
  public OttoReceiveService(OttoActivityService ottoActivityService,
                            SubscriptionRepository subscriptionRepository)
  {
    this.ottoActivityService = ottoActivityService;
    this.subscriptionRepository = subscriptionRepository;
  }

  public Response<Activity> getActivityById(String activityId)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public Response<Activity> processActivity(Activity activity)
  {
    return ottoActivityService.processMission(activity);
  }

  public Response<Activity> updateActivity(Activity activity)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public boolean deleteActivity(String activityId)
  {
    return ottoActivityService.cancelMission(activityId);
  }

  public ResponseEntity<DeviceEvent> getDeviceEventById(String identifier)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public ResponseEntity<List<DeviceEvent>> findAllByTimeStamp(OffsetDateTime timeStamp)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public ResponseEntity<Property> getDeviceProperty(String propertyId)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public ResponseEntity<Property> addDeviceProperty(Property property)
  {
    throw new UnsupportedOperationException("Not implemented yet.");
  }

  public ResponseEntity<Response<Subscription>> addSubscription(Subscription subscription)
  {
    if (subscriptionRepository.findById(subscription.getId()).isPresent())
    {
      ApiError apiError = ApiError.builder()
          .errorId(CALLBACK_URL_ALREADY_EXISTS_ID)
          .description(CALLBACK_URL_ALREADY_EXISTS_DESCRIPTION).build();
      return new ResponseEntity<>(Response.<Subscription>builder().
                                      message(subscription).
                                      errors(List.of(apiError)).
                                      build(), HttpStatus.BAD_REQUEST);
    }
    else
    {
      if (isValid(String.valueOf(subscription.getUrl())))
      {
        subscriptionRepository.save(subscription);
      }
      else
      {
        ApiError apiError = ApiError.builder()
            .errorId(INVALID_CALLBACK_URL_ID)
            .description(INVALID_CALLBACK_URL_DESCRIPTION).build();
        return new ResponseEntity<>(Response.<Subscription>builder().
                                        message(subscription).
                                        errors(List.of(apiError)).
                                        build(), HttpStatus.BAD_REQUEST);
      }
      return ResponseEntity.ok(Response.<Subscription>builder().
                                   message(subscription).
                                   build());
    }
  }

  public ResponseEntity<Response<Subscription>> updateSubscription(Subscription subscription)
  {
    Optional<Subscription> subscriptionExist = subscriptionRepository.findById(subscription.getId());
    if (subscriptionExist.isPresent())
    {
      Subscription existingSubscription = subscriptionExist.get();
      existingSubscription.setType(null == subscription.getType() ? SubscriptionType.ALL
                                                                  : subscription.getType());
      subscriptionRepository.save(existingSubscription);
      return ResponseEntity.ok(Response.<Subscription>builder().
                                   message(subscription).
                                   build());
    }
    else
    {
      List<ApiError> apiError = List.of(ApiError.builder().
                                            errorId(CALLBACK_URL_DOES_NOT_EXIST_ID).
                                            description(CALLBACK_URL_DOES_NOT_EXIST_DESCRIPTION)
                                            .build());
      return new ResponseEntity<>(Response.<Subscription>builder().
                                      message(subscription).
                                      errors(apiError).
                                      build(), HttpStatus.BAD_REQUEST);
    }
  }

  public boolean cancelSubscription(String callbackUrl)
  {
    String callbackUrlDecoded = URLDecoder.decode(callbackUrl, StandardCharsets.UTF_8);
    if (isValid(callbackUrlDecoded))
    {
      if (subscriptionRepository.findById(String.valueOf(URI.create(callbackUrlDecoded))).isPresent())
      {
        subscriptionRepository.deleteById(String.valueOf(URI.create(callbackUrlDecoded)));
      }
      else
      {
        return false;
      }
      return true;
    }
    else
    {
      return false;
    }
  }

  private static boolean isValid(String url)
  {
    try
    {
      // try creating a valid URL
      return new URL(url).toURI() != null;
    }
    catch (URISyntaxException | MalformedURLException e)
    {
      return false;
    }
  }
}
