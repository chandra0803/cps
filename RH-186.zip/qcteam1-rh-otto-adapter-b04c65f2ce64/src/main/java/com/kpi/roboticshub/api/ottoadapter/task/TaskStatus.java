/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.task;

import java.util.Arrays;
import java.util.Objects;

/**
 * Contains all {@link TaskResult#getStatus()} values.
 *
 * @author Jacob.Richards
 */
public enum TaskStatus
{
  BLOCKED("Blocked"),
  CANCELLED("Cancelled"),
  EXECUTING("Executing"),
  FAILED("Failed"),
  QUEUED("Queued"),
  STOPPED("Stopped"),
  SUCCEEDED("Succeeded"),
  UNDEFINED("Undefined");

  private final String name;

  /**
   * Create a new instance of the {@link TaskStatus} enum.
   */
  TaskStatus(String name)
  {
    this.name = name;
  }

  /**
   * @return the {@code name}
   */
  public String getName()
  {
    return name;
  }

  /**
   * Gets the {@link TaskStatus} associated with the {@code name}.
   *
   * @param name used to find a {@link TaskStatus}.
   */
  public static TaskStatus getFromValue(String name)
  {
    return Arrays.asList(values())
        .parallelStream()
        .filter(x -> Objects.equals(x.getName(), name))
        .findAny()
        .orElse(UNDEFINED);
  }
}
