/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

/**
 * Represents Common otto get request class
 *
 * @author KarnakarChitikaneni
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OttoGetRequest
{
  /**
   * Fields to include in returned records.
   * <p>
   * If not present, only the default fields will be included.
   * <p>
   * If "*" is used, all fields will be included.
   */
  private List<String> fields;

  /**
   * The offset of the first record in the returned page.
   * <p>
   * Can be used with any of the Get request to perform pagination.
   */
  private Integer offset;

  /**
   * The maximum number of records to return. If not present the default limit will be used.
   * <p>
   * Can be used with Get request to perform pagination.
   */
  private Integer limit;

  /**
   * The fields used to order returned records. Prefix field name with - for reverse ordering.
   * <p>
   * Multiple fields can be selected. Ordering on multiple fields will be performed in the order the fields are listed.
   */
  private List<String> ordering;

  /**
   * Can be used to get the record with specified id1
   * <p>
   * if not used, all records returned
   */
  private String id;

  /**
   * represents name given to record
   */
  private String name;

  /**
   * Created time stamp of the  record
   */
  private String created;
}
