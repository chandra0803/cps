package com.kpi.roboticshub.ottoadapter.wamp;

import java.util.Arrays;
import java.util.Objects;

/**
 * Contains all {@link WampClient} topics.
 */
public enum Topic
{
  MISSIONS("v2.missions"),
  UNDEFINED("v2.undefined");

  private final String value;

  Topic(String value)
  {
    this.value = value;
  }

  public String getValue()
  {
    return value;
  }

  public static Topic getFromValue(String value)
  {
    return Arrays.asList(values())
        .parallelStream()
        .filter(x -> Objects.equals(x.getValue(), value))
        .findAny()
        .orElse(UNDEFINED);
  }
}
