/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.mongo;

import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Objects;

/**
 * Represents a Sequence Generator class
 *
 * @author KarnakarChitikaneni
 */

@Service
public class DatabaseSequenceGenerator
{
  private final MongoOperations mongoOperations;
  public static final String OTTO_MISSION_ID = "OTTO_MISSION_ID";

  public DatabaseSequenceGenerator(MongoOperations mongoOperations)
  {
    this.mongoOperations = mongoOperations;
  }

  public int getNextSequence()
  {
    final Query query = new Query(Criteria.where("id").is(OTTO_MISSION_ID));
    final Update update = new Update().inc("sequence", 1);
    final DatabaseSequence counter = mongoOperations.findAndModify(query, update, FindAndModifyOptions.options()
        .returnNew(true)
        .upsert(true), DatabaseSequence.class);
    return !Objects.isNull(counter) ? counter.getSequence() : 1;
  }
}
