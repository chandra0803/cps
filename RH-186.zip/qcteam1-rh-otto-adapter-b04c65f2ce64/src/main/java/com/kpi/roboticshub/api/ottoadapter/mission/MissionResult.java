/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.mission;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a {@link Mission} result.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MissionResult extends Mission
{
  @JsonProperty("assigned_robot")
  private String  assignedRobot;
  private String  created;
  @JsonProperty("current_task")
  private Integer currentTask;
  @JsonProperty("due_state")
  private String  dueState;
  @JsonProperty("execution_end")
  private String  executionEnd;
  @JsonProperty("execution_start")
  private String  executionStart;
  @JsonProperty("execution_time")
  private Long    executionTime;
  private String  id;
  @JsonProperty("mission_status")
  private String  missionStatus;
  @JsonProperty("result_text")
  private String  resultText;
  @JsonProperty("result_text_intl_data")
  private String  resultTextData;
  @JsonProperty("result_text_intl_key")
  private String  resultTextKey;
  private String  signature;
}
