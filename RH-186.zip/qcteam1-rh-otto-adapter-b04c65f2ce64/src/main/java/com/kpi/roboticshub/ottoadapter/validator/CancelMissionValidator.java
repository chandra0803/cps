package com.kpi.roboticshub.ottoadapter.validator;

import com.kpi.roboticshub.adapter.validation.ActivityValidator;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.adapter.validation.ValidationService;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.ottoadapter.OttoValidatorProperties;
import org.springframework.stereotype.Component;

@Component
public class CancelMissionValidator extends ActivityValidator
{
  private final OttoCommonValidator ottoCommonValidator;

  public CancelMissionValidator(ValidationService validationService,
                                OttoValidatorProperties ottoValidatorProperties,
                                OttoCommonValidator ottoCommonValidator)
  {
    super(validationService, ottoValidatorProperties.getCancelMissionValidatorProperties());
    this.ottoCommonValidator = ottoCommonValidator;
  }

  @Override
  public void validate(Activity activity) throws ValidationException
  {
    ottoCommonValidator.validateActivityIdExist(activity.getActivityDetail().getActivityId());
    super.validate(activity);
  }
}
