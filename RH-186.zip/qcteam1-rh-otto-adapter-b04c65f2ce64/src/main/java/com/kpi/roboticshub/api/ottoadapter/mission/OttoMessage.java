/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.mission;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a generic OTTO message.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class OttoMessage<T>
{
  private Integer    id;
  @JsonProperty("jsonrpc")
  private String version;
  /**
   * @see MessageMethod
   */
  private String method;
  private T      params;
}
