/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.payload;

import com.kpi.roboticshub.api.ottoadapter.OttoGetRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a payload to get a subset of payload(s).
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GetPayloads extends OttoGetRequest
{
  private String robot;
}
