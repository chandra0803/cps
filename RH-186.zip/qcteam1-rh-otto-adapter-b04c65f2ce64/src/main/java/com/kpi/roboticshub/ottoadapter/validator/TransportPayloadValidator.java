/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.validator;

import com.kpi.roboticshub.adapter.validation.ActivityValidator;
import com.kpi.roboticshub.adapter.validation.ValidationService;
import com.kpi.roboticshub.ottoadapter.OttoValidatorProperties;
import org.springframework.stereotype.Component;

/**
 * Represents a validator for transporting payload from one location to another location
 *
 * @author KarnakarChitikaneni
 */
@Component
public class TransportPayloadValidator extends ActivityValidator
{

  public TransportPayloadValidator(ValidationService validationService,
                                   OttoValidatorProperties ottoValidatorProperties)
  {
    super(validationService, ottoValidatorProperties.getTransportPayloadValidatorProperties());
  }
}
