/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.place.PlaceResult;
import com.kpi.roboticshub.api.ottoadapter.place.PlaceTrafficResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoSendMessageHandler;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.*;

/**
 * Represents a {@link Service} that sends internal requests for {@link PlaceResult}s.
 *
 * @author Jacob.Richards
 */
@Service
public class PlaceService
{
  private final OttoAdapterProperties  properties;
  private final OttoSendMessageHandler ottoSendMessageHandler;

  /**
   * Creates a new instance of the {@link PlaceService} class.
   */
  public PlaceService(OttoAdapterProperties properties,
                      OttoSendMessageHandler ottoSendMessageHandler)
  {
    this.properties = properties;
    this.ottoSendMessageHandler = ottoSendMessageHandler;
  }

  public List<PlaceResult> getPlaces()
  {
    URI url = URI.create(properties.getBaseUrl() + GET_PLACES_PATH);
    return ottoSendMessageHandler.get(getPlaceReference(), url);
  }

  public List<PlaceResult> getPlace(String id)
  {
    String htmlId = HtmlUtils.htmlEscape(id);
    URI url = URI.create(properties.getBaseUrl() + GET_PLACES_ID_PATH + htmlId);
    return ottoSendMessageHandler.get(getPlaceReference(), url);
  }

  public List<PlaceTrafficResult> getPlaceTraffic()
  {
    URI url = URI.create(properties.getBaseUrl() + GET_PLACES_TRAFFIC_PATH);
    return ottoSendMessageHandler.get(getPlaceTrafficReference(), url);
  }

  public List<PlaceTrafficResult> getPlaceTraffic(String id)
  {
    String htmlId = HtmlUtils.htmlEscape(id);
    URI url = URI.create(properties.getBaseUrl() + GET_PLACES_TRAFFIC_ID_PATH + htmlId);
    return ottoSendMessageHandler.get(getPlaceTrafficReference(), url);
  }

  protected ParameterizedTypeReference<List<PlaceResult>> getPlaceReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }

  protected ParameterizedTypeReference<List<PlaceTrafficResult>> getPlaceTrafficReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }
}
