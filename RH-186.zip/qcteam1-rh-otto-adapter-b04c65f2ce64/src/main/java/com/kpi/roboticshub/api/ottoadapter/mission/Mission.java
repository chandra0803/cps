/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.mission;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpi.roboticshub.api.ottoadapter.task.OttoTask;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a payload of ordered {@link OttoTask}s.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Mission
{
  @JsonProperty("client_reference_id")
  private String  clientReferenceId;
  private String  description;
  @JsonProperty("finalized")
  private boolean isFinalized;
  @JsonProperty("force_robot")
  private String  forceRobot;
  @JsonProperty("force_team")
  private String  forceTeam;
  @JsonProperty("max_duration")
  private Long    maxDuration;
  private String  metadata;
  private String  name;
  @JsonProperty("nominal_duration")
  private Long    nominalDuration;
  private Integer     priority;
}
