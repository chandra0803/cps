package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.payload.PayloadResult;

import java.util.List;

/**
 *
 */
public interface PayloadResultService
{
  List<PayloadResult> getPayloadResults();

  List<PayloadResult> getPayloadResults(String activityId);
}
