/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.validation.properties.ActivityValidatorProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;
import org.springframework.boot.context.properties.bind.DefaultValue;

/**
 * Represents a validator properties class
 *
 * @author KarnakarChitikaneni
 */
@ConstructorBinding
@ConfigurationProperties
public class OttoValidatorProperties
{
  private final ActivityValidatorProperties transportPayloadValidatorProperties;

  private final ActivityValidatorProperties pickPayloadValidatorProperties;
  private final ActivityValidatorProperties dropPayloadValidatorProperties;
  private final ActivityValidatorProperties moveToLocationValidatorProperties;
  private final ActivityValidatorProperties retryPayloadValidatorProperties;

  private final ActivityValidatorProperties cancelMissionValidatorProperties;

  /**
   * Creates a new instance of the {@link OttoAdapterProperties} class.
   */
  public OttoValidatorProperties(@DefaultValue ActivityValidatorProperties transportPayloadValidatorProperties,
                                 @DefaultValue ActivityValidatorProperties pickPayloadValidatorProperties,
                                 @DefaultValue ActivityValidatorProperties dropPayloadValidatorProperties,
                                 @DefaultValue ActivityValidatorProperties moveToLocationValidatorProperties,
                                 @DefaultValue ActivityValidatorProperties retryPayloadValidatorProperties,
                                 @DefaultValue ActivityValidatorProperties cancelMissionValidatorProperties)
  {
    this.transportPayloadValidatorProperties = transportPayloadValidatorProperties;
    this.pickPayloadValidatorProperties = pickPayloadValidatorProperties;
    this.dropPayloadValidatorProperties = dropPayloadValidatorProperties;
    this.moveToLocationValidatorProperties = moveToLocationValidatorProperties;
    this.retryPayloadValidatorProperties = retryPayloadValidatorProperties;
    this.cancelMissionValidatorProperties = cancelMissionValidatorProperties;

  }

  public ActivityValidatorProperties getTransportPayloadValidatorProperties()
  {
    return transportPayloadValidatorProperties;
  }

  public ActivityValidatorProperties getPickPayloadValidatorProperties()
  {
    return pickPayloadValidatorProperties;
  }

  public ActivityValidatorProperties getDropPayloadValidatorProperties()
  {
    return dropPayloadValidatorProperties;
  }

  public ActivityValidatorProperties getMoveToLocationValidatorProperties()
  {
    return moveToLocationValidatorProperties;
  }

  public ActivityValidatorProperties getRetryPayloadValidatorProperties()
  {
    return retryPayloadValidatorProperties;
  }

  public ActivityValidatorProperties getCancelMissionValidatorProperties()
  {
    return cancelMissionValidatorProperties;
  }

}
