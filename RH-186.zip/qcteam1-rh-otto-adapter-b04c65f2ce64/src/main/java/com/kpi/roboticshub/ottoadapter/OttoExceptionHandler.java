/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.mongo.ActivityService;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ApiError;
import com.kpi.roboticshub.api.Response;
import com.kpi.roboticshub.api.ottoadapter.ClientException;
import com.kpi.roboticshub.api.ottoadapter.OttoException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Represents a {@link ResponseEntityExceptionHandler} that formats responses.
 *
 * @author Jacob.Richards
 */
@ControllerAdvice
public class OttoExceptionHandler
{
  private final ActivityService activityService;

  /**
   * Creates a new instance of the {@link OttoExceptionHandler} class.
   */
  public OttoExceptionHandler(ActivityService activityService)
  {
    this.activityService = activityService;
  }

  @ExceptionHandler(ValidationException.class)
  protected ResponseEntity<Object> handleValidationException(ValidationException ex)
  {
    if (ex.getClientMessage() instanceof Activity activity)
    {
      saveActivityMessage(activity, ex.getStatus(), ex.getErrors());
    }
    Response<Object> response = Response.builder().build();
    response.setMessage(ex.getClientMessage());
    response.setErrors(ex.getErrors());
    return new ResponseEntity<>(response, ex.getStatus());
  }

  @ExceptionHandler(ClientException.class)
  protected ResponseEntity<Object> handleClientException(ClientException ex)
  {
    if (ex.getClientMessage() instanceof Activity activity)
    {
      saveActivityMessage(activity, ex.getStatus(), ex.getErrors());
    }
    Response<Object> response = Response.builder().build();
    response.setMessage(ex.getClientMessage());
    response.setErrors(ex.getErrors());
    return new ResponseEntity<>(response, ex.getStatus());
  }

  @ExceptionHandler(OttoException.class)
  protected ResponseEntity<Object> handleOttoException(OttoException ex)
  {
    return new ResponseEntity<>(ex.getOttoError(), ex.getStatus());
  }

  private void saveActivityMessage(Activity activity, HttpStatus httpStatus, List<ApiError> apiErrorList)
  {
    if (activity.getActivityDetail() != null &&
        activityService.getRepository().findById(activity.getActivityDetail().getActivityId()).isPresent())
    {
      activityService.update(activity.getActivityDetail().getActivityId(), httpStatus, apiErrorList);
    }
    else if (activity.getActivityDetail() != null)
    {
      activityService.save(activity.getActivityDetail().getActivityId(), OffsetDateTime.now(), activity,
                           httpStatus, apiErrorList);
    }
  }
}
