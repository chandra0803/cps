/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.converter;

import com.kpi.roboticshub.adapter.CommunicationLogService;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import com.kpi.roboticshub.api.ottoadapter.mission.*;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.mongo.DatabaseSequenceGenerator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.integration.config.IntegrationConverter;
import org.springframework.stereotype.Component;

/**
 * Represents a converter of {@link Activity} into {@link OttoMessage}
 */
@Component
@IntegrationConverter
public class OttoRetryMissionConverter implements Converter<Activity, OttoMessage<?>>
{
  private final OttoAdapterProperties ottoAdapterProperties;

  private final DatabaseSequenceGenerator databaseSequenceGenerator;

  private final CommunicationLogService communicationLogService;

  public OttoRetryMissionConverter(OttoAdapterProperties ottoAdapterProperties,
                                   DatabaseSequenceGenerator databaseSequenceGenerator,
                                   CommunicationLogService communicationLogService
  )
  {
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.databaseSequenceGenerator = databaseSequenceGenerator;
    this.communicationLogService = communicationLogService;
  }

  public OttoMessage<?> convert(Activity activity)
  {

    OttoMessage<?> ottoMessage = OttoMessage.builder()
        .id(databaseSequenceGenerator.getNextSequence())
        .method(MessageMethod.RETRY_MISSION.getMethod())
        .version(ottoAdapterProperties.getVersion())
        .params(buildRetryMissionRequest(activity))
        .build();

    communicationLogService.translated(ottoMessage, Activity.class, OttoMessage.class);

    return ottoMessage;
  }

  private RetryMission buildRetryMissionRequest(Activity activity)
  {
    return RetryMission.builder().id(activity.getActivityDetail().getActivityId())
        .build();
  }
}