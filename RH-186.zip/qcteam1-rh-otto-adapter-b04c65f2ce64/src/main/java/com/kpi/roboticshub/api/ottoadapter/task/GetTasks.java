/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * Represents a payload to get a subset of {@link OttoTask}s.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GetTasks
{
  private List<String> fields;
  private Integer      offset;
  private Integer      limit;
  private List<String> order;
  private String       id;
  private String       status;
  private String       mission;
  @JsonProperty("created_gate")
  private String       createdGte;
  @JsonProperty("created_lte")
  private String       createdLte;
  @JsonProperty("execution_start_gte")
  private String       executionStartGte;
  @JsonProperty("execution_start_lte")
  private String       executionStartLte;
  @JsonProperty("execution_end_gte")
  private String       executionEndGte;
  @JsonProperty("execution_end_lte")
  private String       executionEndLte;
}
