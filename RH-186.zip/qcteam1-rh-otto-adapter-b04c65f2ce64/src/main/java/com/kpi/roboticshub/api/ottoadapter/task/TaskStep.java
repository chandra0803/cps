/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * Represents an atomic operation for an OTTO device.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TaskStep
{
  @JsonProperty("goal_timeout")
  private String  goalTimeout;
  @JsonProperty("target_number")
  private String  targetNumber;
  private String  description;
  private String  id;
  @JsonProperty("interruptable")
  private boolean isInterruptable;
  @JsonProperty("step_type")
  private String  stepType;
}
