package com.kpi.roboticshub.ottoadapter;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class OttoConstant
{
  // Constant for system and device ID for OTTO requests.
  public static final String SYSTEM_ID = "OTTO";
}
