/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.mission;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpi.roboticshub.api.ottoadapter.task.OttoTask;
import lombok.*;

import java.util.List;

/**
 * Represents a request to create a mission.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CreateMission
{
  private Mission        mission;
  @JsonProperty("taskList")
  private List<OttoTask> tasks;
}
