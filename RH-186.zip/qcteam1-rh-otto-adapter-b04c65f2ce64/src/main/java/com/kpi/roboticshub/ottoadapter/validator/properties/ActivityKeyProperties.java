/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.validator.properties;

import com.kpi.roboticshub.ottoadapter.ActivityKey;
import lombok.Getter;
import lombok.Setter;

/**
 * Represents an activity conversion properties for given {@link ActivityKey}
 *
 * @author KarnakarChitikaneni
 */
@Getter
@Setter
public class ActivityKeyProperties
{

  private String validatorType;
  private String converterType;

}
