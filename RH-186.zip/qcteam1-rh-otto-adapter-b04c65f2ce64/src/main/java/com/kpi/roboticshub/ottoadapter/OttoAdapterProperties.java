/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.ottoadapter.validator.properties.ActivityKeyProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.ConstructorBinding;

import java.net.URI;
import java.util.Map;

/**
 * Represents {@link OttoAdapterApplication} properties.
 *
 * @author sja
 */
@ConstructorBinding
@ConfigurationProperties(prefix = "otto")
public class OttoAdapterProperties
{

  private final URI baseUrl;

  /**
   * The map of RH client locations to OTTO locations.
   * <p>
   * Used for bi-directional location conversion.
   */
  private final BiMap<String, String> locationMap;

  /**
   * The Otto API version used in POST requests.
   */
  private final String version;

  /**
   * The map of {@link Activity#getDeviceType()} and {@link Activity#getActivityType()} to conversion information.
   */
  private final Map<ActivityKey, ActivityKeyProperties> activityConversions;


  /**
   * Creates a new instance of the {@link OttoAdapterProperties} class.
   */
  public OttoAdapterProperties(URI baseUrl,
                               Map<String, String> locationMap, String version,
                               Map<ActivityKey, ActivityKeyProperties> activityConversions)
  {
    this.baseUrl = baseUrl;
    this.locationMap = HashBiMap.create(locationMap == null ? Map.of() : locationMap);
    this.version = version;
    this.activityConversions = activityConversions;
  }

  /**
   * @return the {@code baseUrl}
   */
  public URI getBaseUrl()
  {
    return baseUrl;
  }

  /**
   * @return the {@code locationMap}
   */
  public BiMap<String, String> getLocationMap()
  {
    return locationMap;
  }

  /**
   * @return the {@code version}
   */
  public String getVersion()
  {
    return version;
  }

  public Map<ActivityKey, ActivityKeyProperties> getActivityConversions()
  {
    return activityConversions;
  }

}
