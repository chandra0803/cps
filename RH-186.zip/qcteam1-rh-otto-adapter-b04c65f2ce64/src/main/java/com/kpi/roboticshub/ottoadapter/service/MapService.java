/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.map.MapResult;
import com.kpi.roboticshub.api.ottoadapter.place.PlaceResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoSendMessageHandler;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_MAPS_ID_PATH;
import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_MAPS_PATH;

/**
 * Represents a {@link Service} that sends internal requests for {@link MapResult}s.
 *
 * @author Jacob.Richards
 */
@Service
public class MapService
{
  private final OttoAdapterProperties  properties;
  private final OttoSendMessageHandler ottoSendMessageHandler;

  /**
   * Creates a new instance of the {@link MapService} class.
   */
  public MapService(OttoAdapterProperties properties,
                    OttoSendMessageHandler ottoSendMessageHandler)
  {
    this.properties = properties;
    this.ottoSendMessageHandler = ottoSendMessageHandler;
  }

  public List<MapResult> getMapResults()
  {
    URI url = URI.create(properties.getBaseUrl() + GET_MAPS_PATH);
    return ottoSendMessageHandler.get(getMapReference(), url);
  }

  public List<MapResult> getMapResults(String id)
  {
    String htmlId = HtmlUtils.htmlEscape(id);
    URI url = URI.create(properties.getBaseUrl() + GET_MAPS_ID_PATH + htmlId);
    return ottoSendMessageHandler.get(getMapReference(), url);
  }

  protected ParameterizedTypeReference<List<MapResult>> getMapReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }
}