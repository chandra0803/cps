package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.mission.MissionResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoSendMessageHandler;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_MISSION_PATH;

@Service
public class DefaultMissionResultService implements MissionResultService
{
  private final OttoAdapterProperties  ottoAdapterProperties;
  private final OttoSendMessageHandler ottoSendMessageHandler;

  public DefaultMissionResultService(OttoAdapterProperties ottoAdapterProperties,
                                     OttoSendMessageHandler ottoSendMessageHandler)
  {
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.ottoSendMessageHandler = ottoSendMessageHandler;
  }

  public List<MissionResult> getMissionResults()
  {
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + GET_MISSION_PATH + "?fields=*");
    return ottoSendMessageHandler.get(getReference(), url);

  }

  public List<MissionResult> getMissionResults(String activityId)
  {
    String htmlId = HtmlUtils.htmlEscape(activityId);
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + GET_MISSION_PATH
                         + "?fields=*&client_reference_id=" + htmlId);
    return ottoSendMessageHandler.get(getReference(), url);
  }

  protected ParameterizedTypeReference<List<MissionResult>> getReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }
}

