/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter;

import com.kpi.roboticshub.api.ottoadapter.mission.OttoMessage;

import java.util.Arrays;
import java.util.Objects;

/**
 * Contains all {@link OttoMessage#getMethod()} values.
 *
 * @author sja
 */
public enum MessageMethod
{
  CREATE_MISSION("createMission"),
  UPDATE_MISSION("updateMission"),
  CANCEL_MISSION("cancelMission"),
  RETRY_MISSION("retryMission"),
  RESUME_MISSION("resumeMission"),
  RESTART_MISSION_AT_TASK("restartMissionAtTask"),
  PURGE_TERMINAL_MISSIONS("purgeTerminalMissions"),
  DELETE_TERMINAL_MISSION("deleteTerminalMission"),
  CREATE_PAYLOAD("createPayload"),
  SET_PLACE_CONTAINER("setPlaceContainer"),
  CREATE_PLACES("createPlaces"),
  DELETE_PLACES("deletePlaces"),
  SET_PLACES("setPlaces"),
  UPDATE_PLACES("updatePlaces"),
  CREATE_CONTAINER("createContainer"),
  DELETE_CONTAINER("deleteContainer"),
  UPDATE_CONTAINER("updateContainer"),
  UNDEFINED("undefined");

  private final String method;

  /**
   * Create a new instance of the {@link MessageMethod} enum.
   */
  MessageMethod(String method)
  {
    this.method = method;
  }

  /**
   * @return the {@code method}
   */
  public String getMethod()
  {
    return method;
  }

  /**
   * Gets the {@link MessageMethod} associated with the {@code method}.
   *
   * @param method the method as a {@link String}.
   * @return the {@link MessageMethod} when it exists; otherwise, {@link MessageMethod#UNDEFINED}.
   */
  public static MessageMethod getFromValue(String method)
  {
    return Arrays.asList(values())
        .parallelStream()
        .filter(x -> Objects.equals(x.getMethod(), method))
        .findAny()
        .orElse(UNDEFINED);
  }
}
