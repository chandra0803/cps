package com.kpi.roboticshub.ottoadapter.validator;

import com.kpi.roboticshub.adapter.mongo.ActivityService;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.ApiError;
import com.kpi.roboticshub.api.ApiErrorConstants;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 *  Represents a common validator to validate database value
 */
@Component
public class OttoCommonValidator
{
  private final ActivityService activityService;

  public OttoCommonValidator(ActivityService activityService)
  {
    this.activityService = activityService;
  }

  public void validateActivityIdExist(String activityId) throws ValidationException
  {
    List<ApiError> errors = new ArrayList<>();
    if (activityService.getRepository()
              .findByIdAndStatus(activityId, HttpStatus.OK) == null)
    {

      errors.add(ApiError.builder().errorId(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_ID)
                     .description(ApiErrorConstants.ACTIVITY_ID_DOES_NOT_EXIST_DESCRIPTION).build());

    }

    if (!errors.isEmpty())
    {
      throw new ValidationException(activityId, errors);
    }
  }
}
