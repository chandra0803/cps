/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.containertype;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * Represents a robot properties class
 *
 * @author KarnakarChitikaneni
 */
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class RobotProperties
{
  @JsonProperty("robot_property_name")
  private String robotPropertyName;
  @JsonProperty("robot_property_type")
  private String robotPropertyType;
}
