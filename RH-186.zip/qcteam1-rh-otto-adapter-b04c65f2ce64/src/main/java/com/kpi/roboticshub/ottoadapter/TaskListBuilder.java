/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.google.common.collect.BiMap;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ActivityType;
import com.kpi.roboticshub.api.ApiError;
import com.kpi.roboticshub.api.ApiErrorConstants;
import com.kpi.roboticshub.api.Location;
import com.kpi.roboticshub.api.ottoadapter.task.OttoTask;
import com.kpi.roboticshub.api.ottoadapter.task.OttoTaskType;
import com.kpi.roboticshub.ottoadapter.mongo.ContainerExternalReference;
import com.kpi.roboticshub.ottoadapter.mongo.ContainerExternalReferenceRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Represents an Otto Task List builder for given {@link Activity} request
 *
 * @author KarnakarChitikaneni
 */
@Component
public class TaskListBuilder
{
  private static final List<String>          TRANSPORT_PAYLOAD_ACTIVITY_TYPES = List.of(ActivityType.SHUFFLE.getType(),
                                                                                        ActivityType.STORE.getType(),
                                                                                        ActivityType.RETRIEVE.getType());
  private final        BiMap<String, String> locationMap;

  private final ContainerExternalReferenceRepository containerExternalReferenceRepository;

  public TaskListBuilder(OttoAdapterProperties ottoAdapterProperties,
                         ContainerExternalReferenceRepository containerExternalReferenceRepository)
  {
    this.locationMap = ottoAdapterProperties.getLocationMap();
    this.containerExternalReferenceRepository = containerExternalReferenceRepository;
  }

  public OttoTask buildMoveTask(Activity activity, Location location)
  {
    return OttoTask.builder()
        .place(getLocationTranslation(location.getLocationId()))
        .taskType(OttoTaskType.MOVE.name()).build();

  }

  public OttoTask buildLoadTask(Activity activity)
  {
    return OttoTask.builder()
        .place(
            getLocationTranslation(activity.getActivityDetail().getContainers().get(0).getLocation().getLocationId()))
        .payload(getPayloadTranslation(activity.getActivityDetail().getContainers().get(0).getContainerId()))
        .taskType(OttoTaskType.LOAD.name()).build();
  }

  public OttoTask buildTransportTask(Activity activity)
  {
    return OttoTask.builder()
        .payload(getPayloadTranslation(activity.getActivityDetail().getContainers().get(0).getContainerId()))
        .place(getLocationTranslation(activity.getActivityDetail().getDestination().getLocationId()))
        .taskType(OttoTaskType.TRANSPORT.name()).build();
  }

  public OttoTask buildUnloadTask(Activity activity)
  {
    return OttoTask.builder()
        .payload(getPayloadTranslation(activity.getActivityDetail().getContainers().get(0).getContainerId()))
        .place(getLocationTranslation(activity.getActivityDetail().getDestination().getLocationId()))
        .taskType(OttoTaskType.UNLOAD.name()).build();
  }

  public List<OttoTask> buildTransportPayloadTaskList(Activity activity)
  {
    List<OttoTask> ottoTasks = new ArrayList<>();
    ottoTasks.add(this.buildMoveTask(activity, activity.getActivityDetail().getContainers().get(0).getLocation()));
    ottoTasks.add(this.buildLoadTask(activity));
    ottoTasks.add(this.buildTransportTask(activity));
    ottoTasks.add(this.buildUnloadTask(activity));
    return ottoTasks;
  }

  public List<OttoTask> getTaskList(Activity activity)
  {
    List<OttoTask> ottoTasks = new ArrayList<>();
    if (isTransportPayload(activity.getActivityType()))
    {
      ottoTasks.addAll(this.buildTransportPayloadTaskList(activity));
    }
    else if (activity.getActivityType().equals(ActivityType.MOVE.getType()))
    {
      ottoTasks.add(this.buildMoveTask(activity, activity.getActivityDetail().getDestination()));
    }
    else if (activity.getActivityType().equals(ActivityType.PICK.getType()))
    {
      ottoTasks.add(this.buildLoadTask(activity));
    }
    else if (activity.getActivityType().equals(ActivityType.DROP.getType()))
    {
      ottoTasks.add(this.buildUnloadTask(activity));
    }
    else
    {
      ApiError error = ApiError.builder()
          .errorId(ApiErrorConstants.UNEXPECTED_FAILURE_ID)
          .description(ApiErrorConstants.UNEXPECTED_FAILURE_FORMAT.formatted("Unsupported activityType"))
          .build();

      throw new ValidationException(activity, List.of(error));
    }

    return ottoTasks;
  }

  private boolean isTransportPayload(String activityType)
  {
    return TRANSPORT_PAYLOAD_ACTIVITY_TYPES.contains(activityType);
  }

  private String getLocationTranslation(String locationId)
  {
    String locationTranslation = locationMap.get(locationId);
    return locationTranslation != null ? locationTranslation : locationId;
  }

  private String getPayloadTranslation(String containerId)
  {
    Optional<ContainerExternalReference> containerExternalReference = containerExternalReferenceRepository.findById(
        containerId);

    if (containerExternalReference.isPresent())
    {
      return containerExternalReference.get().getPayloadId();
    }
    else
    {
      String uuid = UUID.randomUUID().toString();
      ContainerExternalReference externalReference = ContainerExternalReference.builder().id(containerId)
          .payloadId(uuid).build();
      containerExternalReferenceRepository.save(externalReference);
      return uuid;
    }
  }

}
