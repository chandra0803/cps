package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.payload.PayloadResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoSendMessageHandler;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.PAYLOAD_OPERATIONS_PATH;

/**
 * Represents a {@link Service} that sends internal requests for {@link PayloadResult}s.
 */
@Service
public class DefaultPayloadResultService implements PayloadResultService
{
  private final OttoAdapterProperties  ottoAdapterProperties;

  private final  OttoSendMessageHandler ottoSendMessageHandler;

  /**
   * Creates a new instance of the {@link DefaultPayloadResultService} class.
   */
  public DefaultPayloadResultService(OttoAdapterProperties ottoAdapterProperties,
                                     OttoSendMessageHandler ottoSendMessageHandler)
  {
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.ottoSendMessageHandler = ottoSendMessageHandler;
  }

  @Override
  public List<PayloadResult> getPayloadResults()
  {
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + PAYLOAD_OPERATIONS_PATH + "?fields=*");
    return ottoSendMessageHandler.get(getReference(), url);
  }

  @Override public List<PayloadResult> getPayloadResults(String activityId)
  {
    String htmlId = HtmlUtils.htmlEscape(activityId);
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + PAYLOAD_OPERATIONS_PATH
                         + "?fields=*&id=" + htmlId);
    return ottoSendMessageHandler.get(getReference(), url);
  }

  protected ParameterizedTypeReference<List<PayloadResult>> getReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }
}
