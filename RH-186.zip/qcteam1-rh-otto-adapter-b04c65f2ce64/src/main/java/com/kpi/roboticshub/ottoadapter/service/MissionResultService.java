package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.mission.MissionResult;

import java.util.List;


public interface MissionResultService
{
  List<MissionResult> getMissionResults();
  List<MissionResult> getMissionResults(String activityId);
}
