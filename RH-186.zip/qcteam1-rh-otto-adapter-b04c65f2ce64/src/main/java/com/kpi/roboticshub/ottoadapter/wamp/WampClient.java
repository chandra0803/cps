package com.kpi.roboticshub.ottoadapter.wamp;

import com.kpi.roboticshub.ottoadapter.OttoRuntimeException;
import io.crossbar.autobahn.wamp.Client;
import io.crossbar.autobahn.wamp.Session;
import io.crossbar.autobahn.wamp.types.EventDetails;
import io.crossbar.autobahn.wamp.types.SessionDetails;
import io.crossbar.autobahn.wamp.types.Subscription;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.SmartLifecycle;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

/**
 * Represents a WAMP client that subscribes to {@link Topic}s to receive asynchronous messages.
 */
@Component
public class WampClient implements SmartLifecycle
{
  private static final Logger LOGGER = LogManager.getLogger();

  @Value("${wamp.base-url}")
  private String url;
  @Value("${wamp.realm}")
  private String realm;

  private final Executor executor;
  private final Session  session;
  private       boolean  isRunning;

  /**
   * Creates a new instance of the {@link WampClient} class.
   */
  public WampClient()
  {
    this.executor = Executors.newSingleThreadExecutor();
    this.session = new Session(executor);
    this.session.addOnJoinListener(this::subscribe);
  }

  public void start()
  {
    var client = new Client(session, url, realm, executor);
    try
    {
      client.connect().get();
      isRunning = true;
    }
    catch (InterruptedException | ExecutionException e)
    {
      // throw a runtime exception to stop the application during start up
      LOGGER.fatal("Unable to start WAMP client. Exception:", e);
      if (e instanceof InterruptedException)
      {
        // re-interrupt
        Thread.currentThread().interrupt();
      }
      throw new OttoRuntimeException("Unable to start WAMP client.", e);
    }
  }

  @Override
  public void stop()
  {
    if (session.isConnected())
    {
      session.leave();
    }
    isRunning = false;
  }

  @Override
  public boolean isRunning()
  {
    return isRunning;
  }

  private void subscribe(Session session, SessionDetails details)
  {
    // subscribe to topic
    List<Topic> topicList = List.of(Topic.values());
    topicList.forEach(topic -> {
      CompletableFuture<Subscription> completableFuture = session.subscribe(topic.getValue(), this::subscribeHandler);
      completableFuture.thenAccept(subscription -> LOGGER.info("Subscribed to topic [{}].", subscription.topic));
    });
  }

  private void subscribeHandler(List<Object> args, EventDetails details)
  {
    // TODO(sja on 11/18/2022 11:06 AM): Add more topics and logic to use them.
    switch (Topic.getFromValue(details.topic))
    {
      case MISSIONS -> LOGGER.trace("Mission topic received:\n{}", args.get(0));
      default -> LOGGER.trace("Unexpected topic [{}] received:\n{}", details.topic, args.get(0));
    }
  }
}
