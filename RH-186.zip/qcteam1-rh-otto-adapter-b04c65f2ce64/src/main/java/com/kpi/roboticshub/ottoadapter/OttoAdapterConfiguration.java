/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.AdapterConfiguration;
import com.kpi.roboticshub.adapter.DefaultCommunicationLogService;
import com.kpi.roboticshub.adapter.controller.RoboticsHubReceiveController;
import com.kpi.roboticshub.adapter.validation.ActivityValidator;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.adapter.validation.properties.ObjectValidationProperties;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ApiError;
import com.kpi.roboticshub.api.Property;
import com.kpi.roboticshub.api.ottoadapter.ClientException;
import com.kpi.roboticshub.api.ottoadapter.mission.MissionResult;
import com.kpi.roboticshub.api.ottoadapter.task.TaskResult;
import com.kpi.roboticshub.ottoadapter.validator.properties.ActivityKeyProperties;
import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import reactor.netty.http.client.HttpClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.kpi.roboticshub.api.ApiErrorConstants.*;

/**
 * Represents a {@link OttoAdapterApplication} configuration.
 *
 * @author sja
 */
@Configuration
@ComponentScan(basePackages = { "com.kpi.roboticshub.adapter" })
@EnableConfigurationProperties({ OttoAdapterProperties.class, OttoValidatorProperties.class })
@EnableRetry
@EnableTransactionManagement
@Import({ DefaultCommunicationLogService.class, RoboticsHubReceiveController.class, AdapterConfiguration.class })
@EnableMongoRepositories(basePackages = { "com.kpi.roboticshub.adapter.mongo",
                                          "com.kpi.roboticshub.ottoadapter.mongo" })
public class OttoAdapterConfiguration
{

  @Autowired
  private ApplicationContext applicationContext;

  /**
   * The {@link HttpClient} to use.
   *
   * @see HttpClient
   */
  @Bean
  @ConditionalOnMissingBean
  public HttpClient httpClient()
  {
    return HttpClient.create().option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000)
        .doOnConnected(c -> c.addHandlerFirst(new ReadTimeoutHandler(15))
            .addHandlerFirst(new WriteTimeoutHandler(15)));
  }

  @Bean
  public Map<String, ObjectValidationProperties> customValidationMap()
  {
    return new HashMap<>();
  }

  /**
   * The {@link OpenAPI} configuration.
   *
   * @see OpenAPI
   */
  @Bean
  @ConditionalOnMissingBean
  public OpenAPI openApi()
  {
    return new OpenAPI()
        .info(new Info().title("OTTO Adapter API")
                  .description("OTTO bi-directional communication adapter")
                  .contact(new Contact().name("KPI Solutions, LLC").url("https://kpisolutions.com/"))
                  .version("v1.0.0"));
  }

  /**
   * The {@link SubscribableChannel} that all messages received from RH clients are routed to.
   */
  @Bean
  public SubscribableChannel hostReceiveChannel()
  {
    return MessageChannels.direct("adapterReceiveChannel").get();
  }

  /**
   * The {@link SubscribableChannel} that all messages received from OTTO are routed to then sent to the RH clients.
   */
  @Bean
  public SubscribableChannel hostSendChannel()
  {
    return MessageChannels.direct("adapterSendChannel").get();
  }

  /**
   * The {@link IntegrationFlow} that processes messages received from RH clients by validating and sending to OTTO.
   */
  @Bean
  public IntegrationFlow hostReceiveFlow(SubscribableChannel hostReceiveChannel,
                                         OttoSendMessageHandler ottoSendMessageHandler,
                                         OttoAdapterProperties ottoAdapterProperties)
  {
    return IntegrationFlows.from(hostReceiveChannel)
        .filter(x -> {
          if (x instanceof Activity activity)
          {
            validate(activity, getActivityKeyProperties(activity,
                                                        ottoAdapterProperties.getActivityConversions()));
          }
          else if (x instanceof Property)
          {

          }
          return true;
        })
        .transform(source -> {
          if (source instanceof Activity activity)
          {
            return convert(activity, getActivityKeyProperties(activity,
                                                              ottoAdapterProperties.getActivityConversions()));
          }
          return source;
        })
        .handle(ottoSendMessageHandler)
        .get();
  }

  private ActivityKeyProperties getActivityKeyProperties(Activity activity,
                                                         Map<ActivityKey, ActivityKeyProperties> activityConversionMap)
      throws ValidationException
  {
    ActivityKey activityKey = ActivityKey.builder()
        .activityType(activity.getActivityType())
        .deviceType(activity.getDeviceType())
        .build();
    ActivityKeyProperties activityKeyProperties = activityConversionMap
        .get(activityKey);
    if (activityKeyProperties == null)
    {
      ApiError apiError = ApiError.builder().errorId(INVALID_DEVICE_OR_ACTIVITY_TYPE_ID)
          .description(INVALID_DEVICE_OR_ACTIVITY_TYPE_DESCRIPTION)
          .build();
      throw new ValidationException(activity, List.of(apiError));
    }
    return activityKeyProperties;
  }

  private void validate(Activity activity, ActivityKeyProperties activityKeyProperties) throws ValidationException
  {
    ActivityValidator validator;
    try
    {
      validator = (ActivityValidator) applicationContext.getBean(
          Class.forName(activityKeyProperties.getValidatorType()));
    }
    catch (ClassNotFoundException | ClassCastException e)
    {
      ApiError apiError = ApiError.builder().errorId(UNEXPECTED_FAILURE_ID)
          .description(UNEXPECTED_FAILURE_FORMAT.formatted("validator not configured properly"))
          .build();
      throw new ClientException(activity, List.of(apiError), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    if (activity.getActivityDetail() != null && activity.getActivityDetail().getPriority() == null)
    {
      activity.getActivityDetail().setPriority(0);
    }
    validator.validate(activity);
  }

  private Object convert(Activity activity, ActivityKeyProperties activityKeyProperties) throws ClientException
  {
    Converter<Activity, ?> converter;
    try
    {
      converter = (Converter<Activity, ?>) applicationContext.getBean(
          Class.forName(activityKeyProperties.getConverterType()));
    }
    catch (ClassNotFoundException e)
    {
      ApiError apiError = ApiError.builder().errorId(UNEXPECTED_FAILURE_ID)
          .description(UNEXPECTED_FAILURE_FORMAT.formatted("converter not configured properly"))
          .build();
      throw new ClientException(activity, List.of(apiError), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    try
    {
      return converter.convert(activity);
    }
    catch (Exception ex)
    {
      ApiError apiError = ApiError.builder().errorId(UNEXPECTED_FAILURE_ID)
          .description(UNEXPECTED_FAILURE_FORMAT.formatted(ex.getMessage()))
          .build();
      throw new ClientException(activity, List.of(apiError), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  /**
   * The {@link IntegrationFlow} that processes messages received from OTTO by validating and sending to RH clients.
   */
  @Bean
  public IntegrationFlow hostSendFlow(SubscribableChannel hostSendChannel)
  {
    return IntegrationFlows.from(hostSendChannel)
        // validate
        .filter(x -> {
          // TODO(sja on 11/8/2022 8:30 PM): add validator calls and sendMessageHandler
          if (x instanceof MissionResult missionResult)
          {

          }
          else if (x instanceof TaskResult taskResult)
          {

          }
          return true;
        })
        // process
        .handle(message -> {
        })
        .get();
  }
}
