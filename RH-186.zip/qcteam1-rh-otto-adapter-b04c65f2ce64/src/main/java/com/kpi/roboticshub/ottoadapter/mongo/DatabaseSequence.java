/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.mongo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;

/**
 * Represents a sequence generator document class
 *
 * @author KarnakarChitikaneni
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public class DatabaseSequence
{
  @Id
  private String id;
  private int sequence;
}
