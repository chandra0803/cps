/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.containertype;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpi.roboticshub.api.ottoadapter.OttoGetRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a get container types request object
 *
 * @author KarnakarChitikaneni
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GetContainerTypes extends OttoGetRequest
{
  @JsonProperty("robot_property_name")
  private String robotPropertyName;
  @JsonProperty("robot_property_type")
  private String robotPropertyType;
}
