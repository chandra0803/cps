/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.CommunicationLogService;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import com.kpi.roboticshub.api.ottoadapter.mission.OttoMessage;
import com.kpi.roboticshub.api.ottoadapter.mission.OttoResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.integration.handler.AbstractMessageHandler;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.function.Function;

/**
 * Represents a {@link AbstractMessageHandler} that sends {@link OttoMessage}s to OTTO endpoints.
 * <p>
 *
 * @author sja
 */
@Component
public class OttoSendMessageHandler extends AbstractMessageHandler
{
  private static final Logger LOGGER = LogManager.getLogger();

  private final WebClient               webClient;
  private final OttoAdapterProperties   properties;
  private final CommunicationLogService communicationLogService;

  /**
   * Creates a new instance of the {@link OttoSendMessageHandler} class.
   */
  public OttoSendMessageHandler(WebClient.Builder webClientBuilder,
                                OttoAdapterProperties properties,
                                CommunicationLogService communicationLogService)
  {
    this.webClient = webClientBuilder.build();
    this.properties = properties;
    this.communicationLogService = communicationLogService;
  }

  protected void handleMessageInternal(Message<?> message)
  {
    if (message.getPayload() instanceof OttoMessage<?> ottoMessage)
    {
      try
      {
        // send message
        OttoResponse<Object> response = send(ottoMessage, getReference(),
                                             getURIForMessageMethod(ottoMessage.getMethod()));
        if (response != null
            && response.getError() != null)
        {
          throw new OttoSendMessageException(HttpStatus.BAD_REQUEST, response.getError().getMessage());
        }
        else
        {
          // log message sent
          communicationLogService.sent(message.getPayload(), properties.getBaseUrl().toString(), null);
        }
      }
      catch (WebClientResponseException ex)
      {
        throw new OttoSendMessageException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
      }
      catch (WebClientRequestException ex)
      {
        throw new OttoSendMessageException(HttpStatus.GATEWAY_TIMEOUT, ex.getMessage());
      }
    }
    // TODO(sja on 11/9/2022 5:21 PM): Add else if as needed
    else
    {
      LOGGER.error("Unexpected message payload type [{}].",
                   message.getPayload().getClass().getSimpleName());
    }
  }

  /**
   * Posts the specified {@code message} to the specified {@code url}.
   *
   * @param message the message to post.
   * @param responseClass the type of the response message.
   * @param url the URL to post the message to.
   * @param <I> the request (input) message type.
   * @param <O> the response (output) message type.
   * @return the response.
   */
  protected <I, O> O send(I message, ParameterizedTypeReference<O> responseClass, URI url)
  {
    Mono<O> response = webClient.post()
        .uri(url)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(message), responseClass)
        .retrieve()
        .onStatus(HttpStatus::is4xxClientError, getException())
        .onStatus(HttpStatus::is5xxServerError, getException())
        .bodyToMono(responseClass);
    return response.block();
  }

  public <O> O get(ParameterizedTypeReference<O> type, URI url)
  {
    Mono<O> response = webClient.get()
        .uri(url)
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .onStatus(HttpStatus::is4xxClientError, getException())
        .onStatus(HttpStatus::is5xxServerError, getException())
        .bodyToMono(type);
    return response.block();
  }

  protected Function<ClientResponse, Mono<? extends Throwable>> getException()
  {
    return ClientResponse::createException;
  }

  /**
   * The reference used for POST responses.
   */
  protected ParameterizedTypeReference<OttoResponse<Object>> getReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }

  public URI getURIForMessageMethod(String method)
  {
    MessageMethod messageMethod = MessageMethod.getFromValue(method);
    URI uri;

    switch (messageMethod)
    {
      case CREATE_MISSION, UPDATE_MISSION, RETRY_MISSION, RESTART_MISSION_AT_TASK, CANCEL_MISSION ->
          uri = URI.create(properties.getBaseUrl() + OttoPathConstants.MISSION_OPERATIONS_PATH);
      default -> uri = properties.getBaseUrl();
    }
    return uri;
  }
}
