/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter;

import com.kpi.roboticshub.api.ottoadapter.mission.OttoResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

/**
 * Represents an exception class that deals with any Otto exception while processing the request.
 *
 * @author Jacob.Richards
 */
public class OttoException extends ResponseStatusException
{
  private final transient OttoResponse<?> ottoResponse;

  /**
   * Creates a new instance of the {@link OttoException} class.
   */
  public OttoException(OttoResponse<?> ottoResponse, HttpStatus status)
  {
    super(status, "Request failed: %s".formatted(ottoResponse.getError()));
    this.ottoResponse = ottoResponse;
  }

  public OttoResponse<?> getOttoResponse()
  {
    return this.ottoResponse;
  }

  public OttoError getOttoError()
  {
    return this.ottoResponse.getError();
  }
}
