/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.adapter.CommunicationLogService;
import com.kpi.roboticshub.adapter.mongo.ActivityService;
import com.kpi.roboticshub.adapter.validation.ValidationException;
import com.kpi.roboticshub.api.*;
import com.kpi.roboticshub.api.ottoadapter.ClientException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandlingException;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Represents a {@link Activity} request processor
 *
 * @author KarnakarChitikaneni
 */
@Slf4j
@Service
public class OttoActivityService
{
  private final ActivityService activityService;

  private final MessageChannel hostReceiveChannel;

  private final OttoAdapterProperties  properties;
  private final CommunicationLogService communicationLogService;

  public OttoActivityService(ActivityService activityService, MessageChannel hostReceiveChannel,
                             OttoAdapterProperties properties,
                             CommunicationLogService communicationLogService)
  {
    this.activityService = activityService;
    this.hostReceiveChannel = hostReceiveChannel;
    this.properties = properties;
    this.communicationLogService = communicationLogService;
  }

  /**
   * Creates Mission request for given activity
   *
   * @return {@link Response<Activity>}
   * @Param activity
   */
  public Response<Activity> processMission(Activity activity)
  {

    Message<Activity> message = MessageBuilder.withPayload(activity).build();

    try
    {
      hostReceiveChannel.send(message);
    }
    catch (MessageHandlingException me)
    {
      ClientException clientException;

      if (me.getCause() instanceof OttoSendMessageException ose)
      {
        ApiError apiError = ApiError.builder().errorId(ApiErrorConstants.UNEXPECTED_FAILURE_ID)
            .description(ApiErrorConstants.UNEXPECTED_FAILURE_FORMAT.formatted(ose.getReason()))
            .build();
        clientException = new ClientException(activity, List.of(apiError), ose.getStatus());
      }
      else if (me.getCause() instanceof ValidationException ve)
      {
        throw ve;
      }
      else if (me.getCause() instanceof ClientException ce)
      {
        throw ce;
      }
      else
      {
        ApiError apiError = ApiError.builder().errorId(ApiErrorConstants.UNEXPECTED_FAILURE_ID)
            .description(ApiErrorConstants.UNEXPECTED_FAILURE_FORMAT.formatted(me.getMessage()))
            .build();
        clientException = new ClientException(activity, List.of(apiError), HttpStatus.INTERNAL_SERVER_ERROR);
      }

      throw clientException;
    }

    activityService.save(activity.getActivityDetail().getActivityId(), OffsetDateTime.now(), activity, HttpStatus.OK,
                         null);

    return Response.<Activity>builder().message(activity).build();
  }

  /**
   * cancel Mission for given activityId
   *
   * @return {@link Response<Activity>}
   * @Param activityId
   */
  public boolean cancelMission(String activityId)
  {
    Activity activity = Activity.builder()
        .systemId(OttoConstant.SYSTEM_ID)
        .deviceType(OttoConstant.SYSTEM_ID)
        .activityType(ActivityType.CANCEL.getType())
        .activityDetail(ActivityDetail.builder().activityId(activityId).build())
        .build();

    Message<Activity> message = MessageBuilder.withPayload(activity).build();

    try
    {
      return hostReceiveChannel.send(message);
    }
    catch (Exception e)
    {
      communicationLogService.failed(message.getPayload(), ApiErrorConstants.UNEXPECTED_FAILURE_ID,
                                     properties.getBaseUrl().toString(), null);
      return false;
    }
  }

}
