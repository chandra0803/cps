/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * Represents a {@link Converter} for {@link ActivityKey}.
 * <p>
 * TODO(sja on 11/8/2022 8:45 PM): Move to rh-adapter-lib.
 *
 * @author sja
 */
@Component
@ConfigurationPropertiesBinding
public class ActivityKeyConverter implements Converter<String, ActivityKey>
{
  @Override
  public ActivityKey convert(String source)
  {
    String[] data = source.split("\\|");
    if (data.length != 2)
    {
      throw new IllegalArgumentException("%s must be in the format of 'DeviceType|ActivityType'."
                                             .formatted(ActivityKey.class.getSimpleName()));
    }
    return new ActivityKey(data[0], data[1]);
  }
}
