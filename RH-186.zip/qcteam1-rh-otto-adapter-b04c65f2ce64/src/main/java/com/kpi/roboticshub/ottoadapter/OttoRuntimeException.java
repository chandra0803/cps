package com.kpi.roboticshub.ottoadapter;

public class OttoRuntimeException extends RuntimeException
{
  /**
   * Creates a new instance of the {@link OttoRuntimeException} class.
   */
  public OttoRuntimeException(String message, Exception e)
  {
    super(message, e);
  }
}
