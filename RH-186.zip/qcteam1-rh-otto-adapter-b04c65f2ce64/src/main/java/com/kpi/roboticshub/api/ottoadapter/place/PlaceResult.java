/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.place;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.kpi.roboticshub.api.ottoadapter.ContainerType;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;
import java.util.Map;

/**
 * Represents a place result.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PlaceResult
{
  private String              created;
  @JsonProperty("container_types_supported")
  private List<ContainerType> containerTypesSupported;
  private String              description;
  @JsonProperty("enabled")
  private boolean             isEnabled;
  @JsonProperty("exit_recipe")
  private String              exitRecipe;
  @JsonProperty("feature_queue")
  private String              featureQueue;
  private String              id;
  private String              name;
  @JsonProperty("ownership_queue")
  private String              ownershipQueue;
  @JsonProperty("place_groups")
  private String              placeGroups;
  @JsonProperty("place_type")
  private String              placeType;
  @JsonProperty("primary_marker_id")
  private String              primaryMarkerId;
  @JsonProperty("primary_marker_intent")
  private String              primaryMarkerIntent;
  @JsonProperty("source_id")
  private String              sourceId;
  private String              zone;
  private List<Map<String, Object>> recipes;
}
