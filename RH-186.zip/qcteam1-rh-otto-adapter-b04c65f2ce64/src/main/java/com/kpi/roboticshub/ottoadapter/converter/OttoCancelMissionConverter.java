package com.kpi.roboticshub.ottoadapter.converter;

import com.kpi.roboticshub.adapter.CommunicationLogService;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import com.kpi.roboticshub.api.ottoadapter.mission.*;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.mongo.DatabaseSequenceGenerator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.integration.config.IntegrationConverter;
import org.springframework.stereotype.Component;

@Component
@IntegrationConverter
public class OttoCancelMissionConverter implements Converter<Activity, OttoMessage<?>>
{
  private final OttoAdapterProperties ottoAdapterProperties;

  private final DatabaseSequenceGenerator databaseSequenceGenerator;

  private final CommunicationLogService communicationLogService;

  public OttoCancelMissionConverter(OttoAdapterProperties ottoAdapterProperties,
                                    DatabaseSequenceGenerator databaseSequenceGenerator,
                                    CommunicationLogService communicationLogService)
  {
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.databaseSequenceGenerator = databaseSequenceGenerator;
    this.communicationLogService = communicationLogService;
  }

  public OttoMessage<?> convert(Activity activity)
  {
    OttoMessage<?> ottoMessage = OttoMessage.builder()
        .id(databaseSequenceGenerator.getNextSequence())
        .method(MessageMethod.CANCEL_MISSION.getMethod())
        .version(ottoAdapterProperties.getVersion())
        .params(buildCancelMissionRequest(activity))
        .build();

    communicationLogService.translated(ottoMessage, Activity.class, OttoMessage.class);

    return ottoMessage;
  }

  private CancelMission buildCancelMissionRequest(Activity activity)
  {
    return CancelMission.builder()
        .id(activity.getActivityDetail().getActivityId())
        .build();
  }

}
