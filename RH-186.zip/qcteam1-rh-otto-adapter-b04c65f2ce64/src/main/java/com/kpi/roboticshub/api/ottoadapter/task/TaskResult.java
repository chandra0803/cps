/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.task;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.OffsetDateTime;

/**
 * Represents a {@link OttoTask} result.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TaskResult extends OttoTask
{
  @JsonProperty("container_empty")
  private boolean        isContainerEmpty;
  @JsonProperty("container_id")
  private String         containerId;
  @JsonProperty("container_type")
  private String         containerType;
  private OffsetDateTime created;
  @JsonProperty("execution_end")
  private OffsetDateTime executionEnd;
  @JsonProperty("execution_start")
  private OffsetDateTime executionStart;
  @JsonProperty("execution_time")
  private Long           executionTime;
  private String         id;
  private String         mission;
  @JsonProperty("new_container_empty")
  private boolean        isNewContainerEmpty;
  @JsonProperty("new_container_id")
  private String         newContainerId;
  @JsonProperty("new_container_type")
  private String         newContainerType;
  @JsonProperty("new_payload")
  private String         newPayload;
  @JsonProperty("place_group")
  private String         placeGroup;
  private boolean        skipped;
  private TaskStatus     status;
  @JsonProperty("task_blocked_action")
  private String         taskBlockedAction;
  @JsonProperty("task_stopped_action")
  private String         taskStoppedAction;
}
