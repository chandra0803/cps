/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.mission;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

/**
 * Represents a payload to get a subset of {@link Mission}s.
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class GetMissions
{
  /**
   * Fields to include in returned records.
   * <p>
   * If not present, only the default fields will be included.
   * <p>
   * If "*" is used, all fields will be included.
   */
  private List<String> fields;

  /**
   * The offset of the first record in the returned page.
   * <p>
   * Can be used with the {@link GetMissions#getLimit()} to perform pagination.
   */
  private Integer offset;

  /**
   * The maximum number of records to return. If not present the default limit will be used.
   * <p>
   * Can be used with the {@link GetMissions#getOffset()} to perform pagination.
   */
  private Integer limit;

  /**
   * The fields used to order returned records. Prefix field name with - for reverse ordering.
   * <p>
   * Multiple fields can be selected. Ordering on multiple fields will be performed in the order the fields are listed.
   */
  private List<String> ordering;

  @JsonProperty("assigned_robot")
  private String  assignedRobot;
  @JsonProperty("client_reference_id")
  private String  clientReferenceId;
  private String  created;
  @JsonProperty("current_task")
  private Integer     currentTask;
  @JsonProperty("due_state")
  private String  dueState;
  @JsonProperty("execution_end")
  private String  executionEnd;
  @JsonProperty("execution_start")
  private String  executionStart;
  @JsonProperty("finalized")
  private boolean isFinalized;
  @JsonProperty("force_robot")
  private String  forceRobot;
  @JsonProperty("force_team")
  private String  forceTeam;
  private String  id;
  @JsonProperty("max_duration")
  private Long    maxDuration;
  private String  metadata;
  @JsonProperty("mission_status")
  private String  missionStatus;
  private String  name;
  @JsonProperty("nominal_duration")
  private Long    nominalDuration;
  @JsonProperty("paused")
  private boolean isPaused;
  private Integer     priority;
  @JsonProperty("result_text")
  private String  resultText;
  private String  signature;
  private String  structure;

  /**
   * Only returns record(s) created at or after the time.
   */
  @JsonProperty("created_gte")
  private String createdGreaterThanOrEqual;

  /**
   * Only returns record(s) created at or before the time.
   */
  @JsonProperty("created_lte")
  private String createdLessThanOrEqual;
  @JsonProperty("execution_start_gte")
  private String executionStartGreaterThanOrEqual;
  @JsonProperty("execution_start_lte")
  private String executionStartLessThanOrEqual;
  @JsonProperty("execution_end_gte")
  private String executionEndGreaterThanOrEqual;
  @JsonProperty("execution_end_lte")
  private String executionEndLessThanOrEqual;
}
