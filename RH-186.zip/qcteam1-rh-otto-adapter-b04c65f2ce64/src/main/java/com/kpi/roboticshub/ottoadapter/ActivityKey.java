/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter;

import com.kpi.roboticshub.api.Activity;
import lombok.*;

/**
 * Represents a unique key for an {@link Activity} conversion.
 * <p>
 * TODO(sja on 11/8/2022 8:45 PM): Move to rh-adapter-lib.
 *
 * @author sja
 */
@Getter
@Builder
@ToString
@AllArgsConstructor
public class ActivityKey
{
  private final String deviceType;
  private final String activityType;

  @Override
  public boolean equals(Object o)
  {
    if (this == o)
    {
      return true;
    }
    if (o == null || getClass() != o.getClass())
    {
      return false;
    }
    ActivityKey that = (ActivityKey) o;
    if (getDeviceType() != null ? !getDeviceType().equals(that.getDeviceType()) : that.getDeviceType() != null)
    {
      return false;
    }
    return getActivityType() != null ? getActivityType().equals(that.getActivityType())
                                     : that.getActivityType() == null;
  }

  @Override
  public int hashCode()
  {
    int result = getDeviceType() != null ? getDeviceType().hashCode() : 0;
    result = 31 * result + (getActivityType() != null ? getActivityType().hashCode() : 0);
    return result;
  }
}
