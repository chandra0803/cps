package com.kpi.roboticshub.ottoadapter;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Contains all OTTO HTTP paths.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class OttoPathConstants
{
  public static final String GET_MISSION_PATH = "/v2/mission/";

  public static final String GET_TASKS_PATH = "/v2/tasks/";

  public static final String GET_PLACES_PATH            = "/v2/places/";
  public static final String GET_PLACES_ID_PATH         = "/v2/places/?id=";
  public static final String GET_PLACES_TRAFFIC_PATH    = "/v2/places/traffic/";
  public static final String GET_PLACES_TRAFFIC_ID_PATH = "/v2/places/traffic/?id=";

  public static final String GET_MAPS_PATH = "/v2/maps/";
  public static final String GET_MAPS_ID_PATH = "/v2/maps/?id=";

  public static final String MISSION_OPERATIONS_PATH = "/v2/operations/";

  public static final String PAYLOAD_OPERATIONS_PATH = "/v2/payloads/";

}
