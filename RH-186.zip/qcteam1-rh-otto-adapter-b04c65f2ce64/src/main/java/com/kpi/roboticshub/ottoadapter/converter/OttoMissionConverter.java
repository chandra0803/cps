/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.ottoadapter.converter;

import com.kpi.roboticshub.adapter.CommunicationLogService;
import com.kpi.roboticshub.adapter.mongo.ActivityService;
import com.kpi.roboticshub.api.Activity;
import com.kpi.roboticshub.api.ottoadapter.MessageMethod;
import com.kpi.roboticshub.api.ottoadapter.mission.CreateMission;
import com.kpi.roboticshub.api.ottoadapter.mission.Mission;
import com.kpi.roboticshub.api.ottoadapter.mission.OttoMessage;
import com.kpi.roboticshub.api.ottoadapter.mission.UpdateMission;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.TaskListBuilder;
import com.kpi.roboticshub.ottoadapter.mongo.DatabaseSequenceGenerator;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpStatus;
import org.springframework.integration.config.IntegrationConverter;
import org.springframework.stereotype.Component;

/**
 * Represents a converter of {@link Activity} into {@link OttoMessage}
 *
 * @author KarnakarChitikaneni
 */
@Component
@IntegrationConverter
public class OttoMissionConverter implements Converter<Activity, OttoMessage<?>>
{

  private final ActivityService activityService;

  private final OttoAdapterProperties ottoAdapterProperties;

  private final TaskListBuilder taskListBuilder;

  private final DatabaseSequenceGenerator databaseSequenceGenerator;

  private final CommunicationLogService communicationLogService;

  public OttoMissionConverter(ActivityService activityService, OttoAdapterProperties ottoAdapterProperties,
                              TaskListBuilder taskListBuilder, DatabaseSequenceGenerator databaseSequenceGenerator,
                              CommunicationLogService communicationLogService)
  {
    this.activityService = activityService;
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.taskListBuilder = taskListBuilder;
    this.databaseSequenceGenerator = databaseSequenceGenerator;
    this.communicationLogService = communicationLogService;
  }

  public OttoMessage<?> convert(Activity activity)
  {
    boolean isActivityExist = false;

    if (activityService.getRepository()
            .findByIdAndStatus(activity.getActivityDetail().getActivityId(), HttpStatus.OK) != null)
    {
      isActivityExist = true;
    }

    OttoMessage<?> ottoMessage = OttoMessage.builder()
        .id(databaseSequenceGenerator.getNextSequence())
        .method(isActivityExist ? MessageMethod.UPDATE_MISSION.getMethod() : MessageMethod.CREATE_MISSION.getMethod())
        .version(ottoAdapterProperties.getVersion())
        .params(isActivityExist ? buildUpdateMissionRequest(activity) : buildCreateMissionRequest(activity))
        .build();

    communicationLogService.translated(ottoMessage, Activity.class, OttoMessage.class);

    return ottoMessage;
  }

  private UpdateMission buildUpdateMissionRequest(Activity activity)
  {
    return UpdateMission.builder()
        .id(activity.getActivityDetail().getActivityId())
        .tasks(taskListBuilder.getTaskList(activity))
        .build();
  }

  private CreateMission buildCreateMissionRequest(Activity activity)
  {
    return CreateMission.builder()
        .mission(Mission.builder()
                     .name(activity.getActivityDetail().getActivityId())
                     .clientReferenceId(activity.getActivityDetail().getActivityId())
                     .isFinalized(true)
                     .priority(activity.getActivityDetail().getPriority()).build())
        .tasks(taskListBuilder.getTaskList(activity))
        .build();
  }

}
