package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.task.TaskResult;

import java.util.List;

public interface TaskResultService
{
  List<TaskResult> getTaskResults();
  List<TaskResult> getTaskResults(String id);
}
