/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.map;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * Represents a maps result
 *
 * @author Jacob.Richards
 */
@Getter
@Setter
@SuperBuilder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class MapResult
{
  @JsonProperty("cached")
  private boolean isCached;
  private String created;
  private String description;
  @JsonProperty("disabled")
  private boolean isDisabled;
  private String id;
  @JsonProperty("last_modified")
  private String lastModified;
  private String name;
  private String project;
  @JsonProperty("source_map")
  private String sourceMap;
  private String tag;
  @JsonProperty("tag_index")
  private Integer tagIndex;
}
