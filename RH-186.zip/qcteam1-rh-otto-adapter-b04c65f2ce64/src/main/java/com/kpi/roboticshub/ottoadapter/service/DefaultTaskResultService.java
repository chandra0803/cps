package com.kpi.roboticshub.ottoadapter.service;

import com.kpi.roboticshub.api.ottoadapter.task.TaskResult;
import com.kpi.roboticshub.ottoadapter.OttoAdapterProperties;
import com.kpi.roboticshub.ottoadapter.OttoSendMessageHandler;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.net.URI;
import java.util.List;

import static com.kpi.roboticshub.ottoadapter.OttoPathConstants.GET_TASKS_PATH;

@Service
public class DefaultTaskResultService implements TaskResultService
{
  private final OttoAdapterProperties  ottoAdapterProperties;
  private final OttoSendMessageHandler ottoSendMessageHandler;

  public DefaultTaskResultService(OttoAdapterProperties ottoAdapterProperties,
                                  OttoSendMessageHandler ottoSendMessageHandler)
  {
    this.ottoAdapterProperties = ottoAdapterProperties;
    this.ottoSendMessageHandler = ottoSendMessageHandler;
  }

  public List<TaskResult> getTaskResults()
  {
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + GET_TASKS_PATH + "?fields=*");
    return ottoSendMessageHandler.get(getReference(), url);
  }

  public List<TaskResult> getTaskResults(String id)
  {
    String htmlId = HtmlUtils.htmlEscape(id);
    URI url = URI.create(ottoAdapterProperties.getBaseUrl() + GET_TASKS_PATH
                         + "?fields=*&id=" + htmlId);
    return ottoSendMessageHandler.get(getReference(), url);
  }

  protected ParameterizedTypeReference<List<TaskResult>> getReference()
  {
    return new ParameterizedTypeReference<>()
    {
    };
  }
}
