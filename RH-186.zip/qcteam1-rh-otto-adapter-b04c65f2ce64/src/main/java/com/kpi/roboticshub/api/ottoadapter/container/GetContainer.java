/* ***************************************************************************************
 * (c) COPYRIGHT Kuecker Pulse Integration, L.P. 2022 All Rights Reserved
 * No part of this copyrighted work may be reproduced, modified, or distributed
 * in any form or by any means without the prior written permission of Kuecker Pulse
 * Integration, L.P.
 ****************************************************************************************/
package com.kpi.roboticshub.api.ottoadapter.container;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.OffsetDateTime;
import java.util.List;

/**
 * Represents a payload for {@link GetContainer}
 *
 * @author PravinVerma
 */
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetContainer
{
  /**
   * Fields to include in returned records.
   * <p>
   * If not present, only the default fields will be included.
   * <p>
   * If "*" is used, all fields will be included.
   */
  private List<String> fields;

  /**
   * The offset of the first record in the returned page.
   * <p>
   * Can be used with the {@link GetContainer#getLimit()} to perform pagination.
   */
  private Integer offset;

  /**
   * The maximum number of records to return. If not present the default limit will be used.
   * <p>
   * Can be used with the {@link GetContainer#getOffset()} to perform pagination.
   */
  private Integer limit;

  /**
   * The fields used to order returned records. Prefix field name with - for reverse ordering.
   * <p>
   * Multiple fields can be selected. Ordering on multiple fields will be performed in the order the fields are listed.
   */
  private List<String> ordering;

  private String id;

  private String name;

  private String place;

  @JsonProperty("container_type")
  private String containerType;

  private String description;

  private boolean empty;

  @JsonProperty("reserved_at")
  private String reservedAt;

  @JsonProperty("reserved_by")
  private String reservedBy;

  private String robot;

  private String state;

  private OffsetDateTime created;
}
