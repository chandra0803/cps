## rh-otto-adapter

  ## 1.17.0
      ### No issue

      **Merged in feature/RH-176-OTTO-Adapter-Implement-Internal-Get-Payloads-API (pull request #23)**

        * Feature/RH-176 OTTO Adapter Implement Internal Get Payloads API
        * RH-176 Internal Get Payloads API
        * RH-176 Internal Get Payloads API
        * fix unit test case
        * fix unit test case
        * fixed unit test cases
        * fixed unit test cases
        * fixed unit test cases
        * added review comments
        * added review comments
        * Approved-by: pravin
        * Approved-by: Shawn Adamek

      [3ee6e90b53d01aa](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/3ee6e90b53d01aa) Veerendra Shukla *2022-11-29 12:47:28*


  ## 1.16.0
      ### No issue

      **Merged in feature/RH-184-otto-adapter---implement-container-message (pull request #20)**

        * RH-184: added container message object
        * RH-184: added container message object
        * Merge remote-tracking branch &#x27;origin/master&#x27; into feature/RH-184-otto-adapter---implement-container-message
        * RH-184: fixed as per PR comments
        * RH-184: fixed for Builder annotation
        * Merged master into feature/RH-184-otto-adapter---implement-container-message
        * Merge remote-tracking branch &#x27;origin/master&#x27; into feature/RH-184-otto-adapter---implement-container-message
        * Merge branch &#x27;feature/RH-184-otto-adapter---implement-container-message&#x27; of https://bitbucket.org/qcteam1/rh-otto-adapter into feature/RH-184-otto-adapter---implement-container-message
        * Approved-by: karnakar chitikaneni
        * Approved-by: Veerendra Shukla

      [2ae2ff37f3e923f](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/2ae2ff37f3e923f) pravin *2022-11-29 11:10:41*


  ## 1.15.1
      ### No issue

      **Merged in RH-208-adapter-lib-validation-fixes (pull request #27)**

        * RH-167:Otto-adapter-get-activity-by-id
        * RH-167:Otto-adapter-get-activity-by-id
        * Approved-by: pravin

      [fb1c893588eee13](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/fb1c893588eee13) karnakar chitikaneni *2022-11-29 07:03:13*


  ## 1.15.0
      ### No issue

      **Merged in feature/RH-177-otto-adapter---implement-internal (pull request #25)**

        * feature/RH-177-otto-adapter---implement-internal
        * feature/RH-177-otto-adapter---implement-internal
        * - Added internal getMaps and getMapsById calls.
        * Approved-by: Shawn Adamek

      [69a75ab8a144b3d](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/69a75ab8a144b3d) Jacob Richards *2022-11-28 22:00:16*


  ## 1.14.0
      ### No issue

      **Merged in feature/RH-191-otto-adapter---implement-containe (pull request #22)**

        * Feature/RH-191 implement container type objects
        * RH-192: create ContainerTypeResult objects
        * RH-192: create ContainerTypeResult objects
        * RH-191: create ContainerType objects
        * Merged master into feature/RH-191-otto-adapter---implement-containe
        * Approved-by: Shawn Adamek

      [8dc5b3782d9dc39](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/8dc5b3782d9dc39) karnakar chitikaneni *2022-11-28 17:20:10*


  ## 1.13.0
      ### No issue

      **Merged in feature/RH-175-otto-adapter---implement-internal (pull request #14)**

        * feature/RH-175-otto-adapter---implement-internal
        * feature/RH-175-otto-adapter---implement-internal
        * - Added PlaceTraffic call to PlaceService.
        * - Added PlaceTrafficTest to PlaceServiceTest.
        * Merge branch &#x27;master&#x27; into feature/RH-175-otto-adapter---implement-internal
        * feature/RH-175-otto-adapter---implement-internal
        * - Resolved issues.
        * - Added GetPlaceTrafficById call.
        * Merge branch &#x27;master&#x27; into feature/RH-175-otto-adapter---implement-internal
        * # Conflicts:
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/OttoPathConstants.java
        * feature/RH-175-otto-adapter---implement-internal
        * Approved-by: Shawn Adamek

      [4cd6a22606ff32c](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/4cd6a22606ff32c) Jacob Richards *2022-11-28 13:57:47*


  ## 1.12.0
      ### No issue

      **Merged in feature/RH-161-otto-adapter-cancel-mission (pull request #19)**

        * Feature/RH-161 otto adapter cancel mission
        * RH-161, cancel mission changes
        * Merge branch &#x27;master&#x27; of https://bitbucket.org/qcteam1/rh-otto-adapter into feature/RH-161-otto-adapter-cancel-mission
        * # Conflicts:
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/OttoPathConstants.java
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/Otto…
        * RH-161, Cancel changes updated.
        * Merge branch &#x27;master&#x27; of https://bitbucket.org/qcteam1/rh-otto-adapter into feature/RH-161-otto-adapter-cancel-mission
        * # Conflicts:
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/OttoActivityService.java
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/Ot…
        * RH-161 , Cancel code format.
        * RH-161, Unit test fix .
        * RH-161, path constant and log update.
        * RH-161, constant access level.
        * RH-161 , Formatting changes.
        * Approved-by: karnakar chitikaneni
        * Approved-by: Veerendra Shukla
        * Approved-by: pravin

      [9861c678a3fc86a](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/9861c678a3fc86a) Nithin Narayanan *2022-11-23 15:05:05*


  ## 1.11.0
      ### No issue

      **Merged in feature/RH-179-update-create-junit (pull request #18)**

        * Feature/RH-179 update create junit
        * RH-179: create-update-junits
        * RH-179: create-update-junits
        * RH-179: create-update-junits
        * RH-179: create-update-junits
        * RH-179: create-update-junits
        * RH-179: create-update-junits
        * RH-179 : create-update-junits
        * Merge branch &#x27;master&#x27; into feature/RH-179-update-create-junit
        * # Conflicts:
        * #	src/main/java/com/kpi/roboticshub/ottoadapter/OttoPathConstants.java
        * RH-179 : create-update-junits
        * RH-179 : create-update-junits
        * Approved-by: Amit  Agarwal
        * Approved-by: Veerendra Shukla

      [32a8fce3a009fb3](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/32a8fce3a009fb3) karnakar chitikaneni *2022-11-23 06:29:49*


  ## 1.10.0
      ### No issue

      **Merged in feature/RH-160-OTTO-Adapter-Implement-Retry-Mission (pull request #17)**

        * RH-160 OTTO -Retry Mission Receive, Validate, Send
        * intial implementaion
        * fixed sonar issues
        * added failed case unit test
        * added failed case unit test
        * added failed case unit test
        * added review comments
        * Approved-by: Shawn Adamek

      [a5dc674005f3c35](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/a5dc674005f3c35) Veerendra Shukla *2022-11-22 18:24:25*


  ## 1.9.1
      ### No issue

      **RH-162:**

        * - Fix Build and Tag pipeline

      [86940e0091790d7](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/86940e0091790d7) Shawn Adamek *2022-11-18 22:54:29*

      **Merged in feature/RH-162-otto-adapter-subscription (pull request #12)**

        * RH-162 Subscription changes.
        * RH-162 Subscription changes.
        * Merge branch &#x27;master&#x27; into feature/RH-162-otto-adapter-subscription
        * # Conflicts:
        * #	build.gradle
        * RH-162
        * - Code clean up
        * RH-162:
        * - Code clean up
        * - Adjust tests
        * - Add TestUtilities.java
        * - Add test specific application.yml
        * RH-162:
        * - Add missing mongo image
        * RH-162:
        * - Add missing mongo image references
        * Approved-by: Shawn Adamek

      [635812f1131b992](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/635812f1131b992) Nithin Narayanan *2022-11-18 22:16:42*


  ## 1.9.0
      ### No issue

      **Merged in feature/RH-164-OTTO-Adapter-Implement-Internal-Get-Tasks-API (pull request #13)**

        * RH-164 OTTO Adapter - Implement Internal Get Tasks API
        * intial implementaion
        * fix unit test case
        * fixed typo
        * Merged master into feature/RH-164-OTTO-Adapter-Implement-Internal-Get-Tasks-API
        * Merged master into feature/RH-164-OTTO-Adapter-Implement-Internal-Get-Tasks-API
        * RH-164
        * - Code clean up
        * Merge remote-tracking branch &#x27;origin/feature/RH-164-OTTO-Adapter-Implement-Internal-Get-Tasks-API&#x27; into feature/RH-164-OTTO-Adapter-Implement-Internal-Get-Tasks-API
        * Approved-by: Shawn Adamek

      [e14ef38a145ed8a](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/e14ef38a145ed8a) Veerendra Shukla *2022-11-18 18:01:15*


  ## 1.8.0
      ### No issue

      **Merged in feature/RH-145-OTTO-Adapter-Implement-web-socket (pull request #8)**

        * RH-145 Otto Adapter implement web socket
        * RH-145 Otto Adapter implement web socket
        * RH-145 Otto Adapter implement web socket
        * RH-145 Otto Adapter implement web socket
        * Merge branch &#x27;master&#x27; into feature/RH-145-OTTO-Adapter-Implement-web-socket
        * # Conflicts:
        * #	build.gradle
        * #	src/main/resources/application.yml
        * RH-145 Otto Adapter implement web socket
        * RH-145 Otto Adapter implement web socket
        * Merge branch &#x27;master&#x27; into feature/RH-145-OTTO-Adapter-Implement-web-socket
        * Merge branch &#x27;master&#x27; into feature/RH-145-OTTO-Adapter-Implement-web-socket
        * RH-145
        * - Code clean up
        * RH-145
        * - Code clean up
        * Approved-by: Shawn Adamek

      [40dd697874af162](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/40dd697874af162) Amit  Agarwal *2022-11-18 16:50:45*


  ## 1.7.0
      ### No issue

      **Merged in feature/RH-163-otto-adapter---implement-create-u (pull request #5)**

        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * Merge branch &#x27;master&#x27; into feature/RH-163-otto-adapter---implement-create-u
        * # Conflicts:
        * #	build.gradle
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * RH-163 : otto-adapter-create-mission
        * Approved-by: Shawn Adamek

      [aa8046d2749f0de](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/aa8046d2749f0de) karnakar chitikaneni *2022-11-18 15:48:52*


  ## 1.6.0
      ### No issue

      **Merged in feature/RH-170-otto-adapter---implement-internal (pull request #10)**

        * feature/RH-170-otto-adapter---implement-internal
        * feature/RH-170-otto-adapter---implement-internal
        * - Added mockserver dependency.
        * - Added PlaceService and PlaceServiceTest.
        * - Adjusted PlaceResult object to better reflect API.
        * - Added public get method to OttoSendMessageHandler.
        * feature/RH-170-otto-adapter---implement-internal
        * - Added mockserver dependency.
        * - Added PlaceService and PlaceServiceTest.
        * - Adjusted PlaceResult object to better reflect API.
        * - Added public get method to OttoSendMessageHandler.
        * Merge branch &#x27;master&#x27; into feature/RH-170-otto-adapter---implement-internal
        * feature/RH-170-otto-adapter---implement-internal
        * - Added mockserver dependency.
        * - Added PlaceService and PlaceServiceTest.
        * - Adjusted PlaceResult object to better reflect API.
        * - Added public get method to OttoSendMessageHandler.
        * Approved-by: Shawn Adamek

      [c99250d1c43235d](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/c99250d1c43235d) Jacob Richards *2022-11-17 22:41:15*


  ## 1.5.0
      ### No issue

      **Merged in feature/RH-158-OTTO-Adapter-Implement-Internal-Get-Missions-API (pull request #9)**

        * Feature/RH-158 OTTO Adapter Implement Internal Get Missions API
        * changed mock object
        * added review comments
        * added unit test case
        * fixed conflicts
        * fixed sonar issues
        * removed unused paramaters
        * removed unused paramaters
        * added review comments
        * added review comments
        * fixed doc comment
        * Approved-by: Shawn Adamek

      [c4efcf9a5263058](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/c4efcf9a5263058) Veerendra Shukla *2022-11-17 21:37:42*


  ## 1.4.0
      ### No issue

      **Merged in feature/RH-179-otto-adapter---implement-update-m (pull request #11)**

        * RH-179: otto-adapter-basic-service-config changes
        * RH-179: otto-adapter-basic-service-config changes
        * Approved-by: Amit  Agarwal
        * Approved-by: Veerendra Shukla

      [57b91a57ad37f5b](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/57b91a57ad37f5b) karnakar chitikaneni *2022-11-17 09:37:49*


  ## 1.3.0
      ### No issue

      **Merged in feature/RH-172-otto-adapter---create-error-handl (pull request #7)**

        * feature/RH-172-otto-adapter---create-error-handl
        * feature/RH-172-otto-adapter---create-error-handl
        * - Create ClientException and OttoException
        * - Create OttoExceptionHandler to handle thrown exceptions.
        * feature/RH-172-otto-adapter---create-error-handl
        * - Fix Errors.
        * Approved-by: Shawn Adamek

      [9005d81f33106bb](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/9005d81f33106bb) Jacob Richards *2022-11-14 14:57:05*


  ## 1.2.3
      ### No issue

      **Merged in RH-165-add-message-method-enum (pull request #4)**

        * RH-165
        * RH-165
        * - Add MessageMethod.java
        * - Add Otto version property

      [8af5d699c582530](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/8af5d699c582530) Shawn Adamek *2022-11-10 18:56:27*


  ## 1.2.2
      ### No issue

      **Merge remote-tracking branch 'origin/master'**


      [f4c7d2a9c215f3a](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/f4c7d2a9c215f3a) Shawn Adamek *2022-11-09 23:55:20*

      **- Add more base code**


      [3e0e7474290cf52](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/3e0e7474290cf52) Shawn Adamek *2022-11-09 23:55:09*


  ## 1.2.1
      ### No issue

      **- Add more base code**


      [d2b3c622298e0b6](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/d2b3c622298e0b6) Shawn Adamek *2022-11-09 22:32:08*


  ## 1.2.0
      ### No issue

      **Merged in feature/RH-150-otto-adapter---add-api-map-place (pull request #3)**

        * feature/RH-150-otto-adapter---add-api-map-place
        * feature/RH-150-otto-adapter---add-api-map-place
        * - Added Map, Payload, Place, PlaceTraffic, and ContainerType objects needed for requests and responses.
        * Merged master into feature/RH-150-otto-adapter---add-api-map-place
        * feature/RH-150-otto-adapter---add-api-map-place
        * - Pull request fixes.
        * feature/RH-150-otto-adapter---add-api-map-place
        * - Remove unused imports.
        * Approved-by: Shawn Adamek

      [ea321c5fa2d3031](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/ea321c5fa2d3031) Jacob Richards *2022-11-09 20:54:05*


  ## 1.1.2
      ### No issue

      **- Add more base code**


      [e2b22684050b0ab](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/e2b22684050b0ab) Shawn Adamek *2022-11-09 20:14:33*


  ## 1.1.1
      ### No issue

      **Merged in RH-142-Updates (pull request #2)**

        * RH-142:
        * RH-142:
        * - Fix RetryMission name
        * - Add stub objects
        * - Add to build.gradle

      [1bd9833f9d207a3](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/1bd9833f9d207a3) Shawn Adamek *2022-11-09 15:36:54*


  ## 1.1.0
      ### No issue

      **Merged in feature/RH-142-OTTO-Adapter-Add-API-Mission-Objects (pull request #1)**

        * feature/RH-142-OTTO-Adapter-Add-API-Mission-Objects
        * feature/RH-142-OTTO-Adapter-Add-API-Mission-Objects
        * - Created objects for mission requests and responses.
        * - Created objects for task requests and responses.
        * RH-142:
        * - Refactor initial commit
        * Approved-by: Shawn Adamek

      [81b56b7ef5fdd86](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/81b56b7ef5fdd86) Jacob Richards *2022-11-09 00:14:42*

      **- Template renames**


      [52be88677381b96](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/52be88677381b96) Shawn Adamek *2022-10-28 12:59:20*

      **RH-32:**

        * - Update template with publishing fixes

      [3f1ec4b38221f4b](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/3f1ec4b38221f4b) Shawn Adamek *2022-08-25 21:21:52*

      **RH-32:**

        * - Add missing build scripts
        * - Add change log
        * - Add tasks to build.gradle
        * - Format build.gradle
        * - Add pipeline

      [5f7a2d766f2b0e9](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/5f7a2d766f2b0e9) Shawn Adamek *2022-08-23 18:39:59*

      **Adjust log4j2-spring.yml**


      [89938d655ca8441](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/89938d655ca8441) Shawn Adamek *2022-08-12 17:33:13*

      **Fix package name**

        * Add boot test
        * Adjust repo version number
        * Adjust read me

      [12112078a4bcbd6](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/12112078a4bcbd6) Shawn Adamek *2022-08-12 17:28:36*

      **Merged in HEAD (pull request #1)**

        * rh-template

      [8780ab12c3fb107](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/8780ab12c3fb107) Srinath Nampallay *2022-08-12 12:27:57*

      **rh-template**


      [d7f252d2419b573](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/d7f252d2419b573) DPLAP245\dP-PL *2022-08-12 12:17:10*

      **README.md edited online with Bitbucket**


      [db9ee91a83ccde3](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/db9ee91a83ccde3) pravin *2022-08-12 12:05:22*

      **Initial commit**


      [7854d04a8d5d5a9](https://bitbucket.org/qcteam1/rh-otto-adapter/commits/7854d04a8d5d5a9) pravin *2022-08-12 12:03:45*


