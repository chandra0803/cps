# Robotics Hub Otto Adapter


Uncomment publish lines in bitbucket-pipelines.yml if the repo should publish artifacts
