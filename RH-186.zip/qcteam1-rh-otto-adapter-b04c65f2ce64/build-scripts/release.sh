#!/usr/bin/env bash

# load version from gradle.properties
LIB_VERSION=$(grep -oP '(?<=(^version = )|(^version=)).*' gradle.properties)
# remove white space from version
LIB_VERSION="$(echo -e "${LIB_VERSION}" | tr -d '[:space:]')"
LIB_VERSION="$(echo -e "${LIB_VERSION}" | tr -d '\r')"
IFS="." read -r -a VERSION_ARRAY<<<"$LIB_VERSION"
LATEST_LOG=$(git log --oneline --decorate -1)
# force minor and patch version to 0
VERSION_ARRAY[2]=0
VERSION_ARRAY[1]=0
# increment major version
((VERSION_ARRAY[0]++ ))
LIB_VERSION=$(IFS="." ; echo "${VERSION_ARRAY[*]}")
# replace old version with new version in gradle.properties
sed -i "s/^\(version=\|version = \).*$/\1$LIB_VERSION/" gradle.properties
echo "$LIB_VERSION"
